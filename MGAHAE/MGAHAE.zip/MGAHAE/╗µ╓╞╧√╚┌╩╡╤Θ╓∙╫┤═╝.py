
# import matplotlib.pyplot as plt
# import numpy as np
#
# # 设置全局字体大小
# plt.rcParams['font.size'] = 7.5
#
# data1 = np.array([
#     [94.43, 92.5, 85.69, 90.53, 93.36],
#     [94.11, 94.35, 93.45, 93.66, 96.08],
#     [87.32, 96.77, 95.83, 84.24, 96.73]
# ])
#
# data2 = np.array([
#     [94.81, 93.00, 81.8, 90.97, 93.91],
#     [94.04, 94.26, 93.38, 93.60, 96.03],
#     [88.93, 96.56, 95.04, 85.11, 96.18],
# ])
#
# # 行名
# labels = ['DBLP', 'ACM', 'Yelp']
#
# # 列名
# categories = ['MGAGNN-f', 'MGAGNN-o', 'MGAGNN-s', 'MGAGNN-mean', 'MGAGNN']
#
# # 设置柱状图参数
# bar_width = 0.15  # 调整柱状图宽度
# space_between_bars = 0.02  # 小间隔
# space_between_rows = 0.3  # 大间隔
#
# # # 设置绘图分辨率为1200dpi
# # fig, axs = plt.subplots(1, 2, figsize=(6, 3), dpi=300)
# fig = plt.figure(figsize=(6, 2), dpi=300)
#
# # 绘制第一个子图
# plt.subplot(121)
#
# bar_positions = np.arange(len(labels)) - bar_width * 2  # 调整柱状图位置
# colors = ['skyblue', 'royalblue', 'yellowgreen', 'green', 'lightcoral']
# for i in range(len(categories)):
#     plt.bar(bar_positions + i * bar_width, data1[:, i] - 75, bar_width, label=categories[i], color=colors[i])
#
# plt.ylabel('Macro-F1')
# plt.yticks(np.arange(0, 26, 5), np.arange(75, 101, 5))
# plt.legend(loc='upper center', bbox_to_anchor=(1.2, 1.25), ncol=len(categories))  # 调整图例位置
# # plt.legend(loc='upper center', bbox_to_anchor=(1.2, 1.2), ncol=3)  # 调整图例位置和列数
#
# # 设置 x 轴标签，并设置字体大小
# plt.xticks(np.arange(len(labels)), labels)  # 调整字体大小
#
# # 设置 x 轴标签
# # plt.xticks(np.arange(len(labels)), labels)
# # 绘制第二个子图
# plt.subplot(122)
#
# bar_positions = np.arange(len(labels)) - bar_width * 2  # 调整柱状图位置
# colors = ['steelblue', 'Darkorange', 'darkgrey', 'orange', 'deepskyblue']
# for i in range(len(categories)):
#     plt.bar(bar_positions + i * bar_width, data2[:, i] - 75, bar_width, label=categories[i], color=colors[i])
#
# plt.ylabel('Micro-F1')
# plt.yticks(np.arange(0, 26, 5), np.arange(75, 101, 5))
#
# # 设置 x 轴标签，并设置字体大小
# plt.xticks(np.arange(len(labels)), labels)  # 调整字体大小
#
# # 设置 x 轴标签
# # plt.xticks(np.arange(len(labels)), labels)
# # # 调整子图之间的间隔
# # plt.subplots_adjust(hspace=space_between_rows)
#
# plt.show()


import matplotlib.pyplot as plt
import numpy as np

# # 输入数据NMI
# data = np.array([
#     [78.65, 74.76, 66.66, 43.39, 79.45],
#     [47.99, 27.33, 7.67, 54.53, 55.08],
#     [38.8, 37.54, 46.74, 26.73, 48.37]
# ])
# # 添加轴标签和标题
# plt.ylabel('NMI(%)')

# # 输入数据ARI
# data = np.array([
#     [84.13, 80.56, 70.13, 43.66, 84.78],
#     [42.71, 24.13, 6.36, 47.31, 47.52],
#     [41.27, 34.00, 44.85, 26.70, 45.53]
# ])
# # 添加轴标签和标题
# plt.ylabel('ARI(%)')

# # 输入数据ACC
# data = np.array([
#     [93.39, 91.94, 82.96, 66.86, 93.69],
#     [66.85, 51.97, 41.27, 64.98, 65.15],
#     [71.08, 67.25, 74.19, 58.40, 73.35]
# ])
# # 添加轴标签和标题
# plt.ylabel('ACC(%)')

# 输入数据F1
data = np.array([
    [92.90, 91.50, 80.19, 63.92, 93.26],
    [64.86, 47.93, 38.24, 56.10, 64.30],
    [52.31, 64.72, 69.38, 52.44, 63.19]
])
# 添加轴标签和标题
plt.ylabel('F1(%)')


# 行名
labels = ['DBLP', 'ACM', 'Yelp']

# 列名
categories = ['MGAHAE-k', 'MGAHAE-s', 'MGAHAE_mean', 'MGAHAE-m', 'MGAHAE']

# 设置柱状图参数
bar_width = 0.15
bar_positions = np.arange(len(labels)) - bar_width

# 绘制柱状图
colors = ['skyblue', 'royalblue', 'yellowgreen', 'green', 'lightcoral']
for i in range(len(categories)):
    plt.bar(bar_positions + i * bar_width, data[:, i], bar_width, label=categories[i], color=colors[i])

# 添加图例
plt.legend()

# 取消x轴的刻度
plt.xticks([])

# 在数据下面显示对应的标签
plt.xticks(bar_positions + bar_width * 2, labels)  # 设置标签位置并添加标签

# # 设置纵轴坐标刻度
# plt.yticks(np.arange(75, 101, 5))

# 显示图形
plt.show()