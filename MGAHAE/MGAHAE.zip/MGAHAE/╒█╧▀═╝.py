# import matplotlib.pyplot as plt
#
# # 示例数据
# x = [1, 2, 3, 4, 5]
# y = [3, 5, 2, 7, 4]
#
# # 绘制折线图
# plt.plot(x, y, marker='o', color='b')  # 折线图，蓝色线条，圆形标记点
#
# # 找到最高点的坐标
# max_y = max(y)
# max_index = y.index(max_y)
# max_x = x[max_index]
#
# # 标记最高点
# plt.scatter(max_x, max_y, color='red', label=f'Max Point ({max_x}, {max_y})')  # 最高点，红色标记
#
# # 添加图例
# plt.legend()
#
# # 添加标题和坐标轴标签
# plt.title('Line Plot with Highest Point Marked')
# plt.xlabel('X-axis')
# plt.ylabel('Y-axis')
#
# # 显示图形
# plt.show()

# x_given = [4, 8, 16, 32, 64, 128]  # 给定的x轴刻度

# import matplotlib.pyplot as plt
# import numpy as np
#
# # 示例数据
# x_given = [4, 8, 16, 32, 64, 128]  # 给定的x轴刻度
# x_interpolated = np.linspace(min(x_given), max(x_given), 100)  # 生成等间距的x轴数据，用于绘制折线图
#
# # 三个折线的y轴数据
# y1 = [95.21, 94.78, 96.08, 95.00, 95.00, 93.45]
# y2 = [93.22, 93.12, 92.69, 91.99, 93.36, 92.54]
# y3 = [96.47, 95.62, 96.12, 92.94, 92.61, 95.52]
#
# # 创建并排列的三个子图
# fig, axs = plt.subplots(1, 3, figsize=(12, 4))
#
# # 绘制第一个子图
# axs[0].plot(x_interpolated, np.interp(x_interpolated, x_given, y1), label='Line 1', color='blue')
# max_index1 = np.argmax(y1)
# axs[0].scatter(x_given[max_index1], y1[max_index1], color='red', marker='o', label='Max Point Line 1')
# axs[0].legend()
# axs[0].set_title('Line 1')
# axs[0].set_xticks(x_given)  # 设置x轴刻度
# axs[0].set_xlabel('X-axis')  # 添加x轴标签
# axs[0].set_ylabel('Y-axis')  # 添加y轴标签
#
# # 绘制第二个子图
# axs[1].plot(x_interpolated, np.interp(x_interpolated, x_given, y2), label='Line 2', color='green')
# max_index2 = np.argmax(y2)
# axs[1].scatter(x_given[max_index2], y2[max_index2], color='red', marker='o', label='Max Point Line 2')
# axs[1].legend()
# axs[1].set_title('Line 2')
# axs[1].set_xticks(x_given)  # 设置x轴刻度
# axs[1].set_xlabel('X-axis')  # 添加x轴标签
# axs[1].set_ylabel('Y-axis')  # 添加y轴标签
#
# # 绘制第三个子图
# axs[2].plot(x_interpolated, np.interp(x_interpolated, x_given, y3), label='Line 3', color='orange')
# max_index3 = np.argmax(y3)
# axs[2].scatter(x_given[max_index3], y3[max_index3], color='red', marker='o', label='Max Point Line 3')
# axs[2].legend()
# axs[2].set_title('Line 3')
# axs[2].set_xticks(x_given)  # 设置x轴刻度
# axs[2].set_xlabel('X-axis')  # 添加x轴标签
# axs[2].set_ylabel('Y-axis')  # 添加y轴标签
#
# # 调整子图之间的间距
# plt.tight_layout()
#
# # 显示图形
# plt.show()

#
# import matplotlib.pyplot as plt
# import numpy as np
#
# # 示例数据
# x = np.linspace(0, 60, 6)  # 生成0到60的6个点作为x轴数据
#
# # # d_r的 Macro_F1
# y1 = [95.21, 94.78, 96.08, 95.00, 95.00, 93.45]
# y2 = [93.22, 93.12, 92.69, 91.99, 93.36, 92.54]
# y3 = [94.02, 95.62, 96.12, 92.94, 92.61, 95.52]
#
# # # d_r的 Micro_F1
# y1 = [95.14, 94.70, 96.03, 94.92, 94.92, 93.38]
# y2 = [93.00, 93.23, 93.45, 93.00, 93.68, 92.78]
# y3 = [93.13, 95.42, 95.42, 92.37, 91.98, 94.66]
#
#
# # 创建并排列的三个子图
# fig, axs = plt.subplots(1, 3, figsize=(14, 4))
#
# # 绘制第一个子图
# axs[0].plot(x, y1, label='Line 1', color='blue')
# max_index1 = np.argmax(y1)
# axs[0].scatter(x[max_index1], y1[max_index1], color='red', marker='o', label='Max Point Line 1')
# # axs[0].legend()
# axs[0].set_title('ACM')
# axs[0].set_xticks(x)  # 设置x轴刻度
# axs[0].set_xticklabels([4, 8, 16, 32, 64, 128])  # 设置x轴刻度标签
# axs[0].set_xlabel('d_r')  # 添加x轴标签
# axs[0].set_ylabel('Micro-F1')  # 添加y轴标签
#
# # 绘制第二个子图
# axs[1].plot(x, y2, label='Line 2', color='green')
# max_index2 = np.argmax(y2)
# axs[1].scatter(x[max_index2], y2[max_index2], color='red', marker='o', label='Max Point Line 2')
# # axs[1].legend()
# axs[1].set_title('DBLP')
# axs[1].set_xticks(x)  # 设置x轴刻度
# axs[1].set_xticklabels([4, 8, 16, 32, 64, 128])  # 设置x轴刻度标签
# axs[1].set_xlabel('d_r')  # 添加x轴标签
# axs[1].set_ylabel('Micro-F1')  # 添加y轴标签
#
# # 绘制第三个子图
# axs[2].plot(x, y3, label='Line 3', color='orange')
# max_index3 = np.argmax(y3)
# axs[2].scatter(x[max_index3], y3[max_index3], color='red', marker='o', label='Max Point Line 3')
# # axs[2].legend()
# axs[2].set_title('Yelp')
# axs[2].set_xticks(x)  # 设置x轴刻度
# axs[2].set_xticklabels([4, 8, 16, 32, 64, 128])  # 设置x轴刻度标签
# axs[2].set_xlabel('d_r')  # 添加x轴标签
# axs[2].set_ylabel('Micro-F1')  # 添加y轴标签
#
# # 调整子图的位置，模拟标题在下方
# plt.subplots_adjust(top=10)
#
# # 调整子图之间的间距
# plt.tight_layout()
#
# # 显示图形
# plt.show()






import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import MaxNLocator

# 示例数据
x = np.linspace(0, 60, 7)  # 生成0到60的6个点作为x轴数据

# # ##### 嵌入维度数据
# # DBLP
# y11 = [70.3, 41.98, 79.51, 79.14, 79.46, 80.03, 79.04]
# y12 = [73.29, 38.45, 84.97, 84.41, 84.66, 85.31, 84.72]
# y13 = [87.63, 59.48, 93.79, 93.52, 93.64, 93.91, 93.69]
# y14 = [86.44, 49.61, 93.35, 93.07, 93.18, 93.48, 93.27]
#
# # ACM
# y21 = [50.81, 54.90, 58.05, 55.83, 55.7, 55.75, 44.24]
# y22 = [45.92, 47.62, 48.22, 48.49, 48.13, 46.71, 37.25]
# y23 = [63.9, 64.46, 65.02, 65.36, 65.4, 64.60, 45.34]
# y24 = [53.93, 54.29, 54.16, 54.50, 55.95, 53.78, 37.89]
#
# # YELP
# y31 = [3.42, 63.82, 62.62, 38.66, 14.26, 62.27, 61.97]
# y32 = [4.52, 61.7, 59.70, 42.47, 9.53, 56.79, 55.25]
# y33 = [44.49, 86.92, 86.11, 65.26, 54.40, 84.81, 83.97]
# y34 = [41.77, 88.47, 87.94, 56.75, 48.96, 86.77, 85.95]


# ##### 超参数a：结构重构
# DBLP
y11 = [48.87, 78.13, 79.19, 79.5, 79.05, 78.39, 79.74]
y12 = [42.54, 83.81, 84.3, 84.84, 84.33, 83.64, 84.98]
y13 = [55.24, 93.25, 93.47, 93.69, 93.52, 93.2, 93.76]
y14 = [35.26, 92.72, 92.93, 93.21, 93.1, 92.75, 93.33]

# ACM
y21 = [1.8, 45.75, 54.88, 46.83, 50.83, 55.37, 53.78]
y22 = [1.44, 41.16, 47.09, 42.71, 46.81, 47.92, 47.92]
y23 = [38.15, 67.8, 66.45, 68.66, 65.95, 64.46, 64.6]
y24 = [36.53, 68.31, 60.73, 69.01, 59.7, 54.54, 54.18]

# YELP
y31 = [57.79, 45.92, 48.67, 49.93, 62.9, 48.04, 45.23]
y32 = [48.46, 42.81, 52.34, 44.3, 59.3, 43.15, 45.14]
y33 = [80.53, 70.5, 75.15, 81.07, 85.92, 80.61, 73.03]
y34 = [82.96, 66.19, 66.58, 80.25, 87.68, 79.54, 74.0]



# # ##### 超参数b：属性解码器超参数
# # DBLP
# y11 = [79.02, 21.9, 79.62, 79.2, 78.24, 79.16, 79.4]
# y12 = [84.66, 22.64, 84.92, 84.78, 83.9, 84.61, 84.99]
# y13 = [93.64, 44.86, 93.76, 93.69, 93.32, 93.59, 93.79]
# y14 = [93.18, 38.65, 93.31, 93.24, 92.88, 93.09, 93.36]
#
# # ACM
# y21 = [54.43, 55.28, 53.11, 58.48, 52.53, 57.65, 57.59]
# y22 = [47.59, 45.61, 44.57, 48.29, 45.08, 49.04, 48.72]
# y23 = [64.4, 64.23, 65.72, 65.06, 69.49, 65.19, 65.16]
# y24 = [54.53, 53.58, 60.25, 54.22, 66.63, 54.15, 54.16]
#
# # YELP
# y31 = [57.79, 30.64, 38.67, 14.26, 33.99, 15.12, 38.7]
# y32 = [48.46, 29.46, 42.34, 9.53, 28.33, 8.62, 42.28]
# y33 = [80.53, 56.92, 65.15, 54.4, 61.52, 54.25, 65.0]
# y34 = [82.96, 47.09, 56.58, 48.96, 58.07, 48.75, 56.57]
#
#
# # ##### 超参数c：模块度最大化超参数
# # DBLP
# y11 = [44.11, 20.3, 79.41, 60.07, 48.47, 48.93, 1.34]
# y12 = [38.43, 18.43, 84.98, 56.94, 42.29, 42.57, 0.93]
# y13 = [65.57, 47.60, 93.81, 69.63, 55.19, 55.24, 31.38]
# y14 = [63.98, 46.08, 93.39, 60.62, 35.22, 35.26, 23.74]
#
# # ACM
# y21 = [48.1, 56.78, 51.91, 46, 40.76, 39.44, 55.09]
# y22 = [37.28, 48.53, 46.76, 40, 40.04, 39.07, 48.24]
# y23 = [56.76, 65.19, 66.45, 65.17, 65.47, 59.17, 65.16]
# y24 = [49.13, 54.1, 61.56, 56.31, 58.35, 55.08, 53.87]
#
# # YELP
# y31 = [25.92, 57.49, 48.04, 41.52, 43.73, 61.84, 60.09]
# y32 = [22.81, 47.54, 43.15, 36.59, 42.51, 57.38, 52.0]
# y33 = [50.5, 79.99, 70.61, 74.37, 72.52, 85.08, 82.44]
# y34 = [46.19, 82.46, 79.54, 72.95, 75.79, 86.94, 84.44]



# 设置全局字体大小
plt.rcParams['font.size'] = 7

# 创建并排列的三个子图
fig, axs = plt.subplots(1, 3, figsize=(7, 2), dpi=300)  # 正常为：figsize=(7, 2)； 模块度最大：figsize=(8, 2)

# ## 线宽设定
line = 0.7
# ## 最大值：红点大小
k = 6

# 绘制第一个子图
axs[0].plot(x, y11, label='NMI', color='blue', linewidth=line)
max_index1 = np.argmax(y11)
axs[0].scatter(x[max_index1], y11[max_index1], color='red', s=k)

axs[0].plot(x, y12, label='ARI', color='orange', linewidth=line)
max_index2 = np.argmax(y12)
axs[0].scatter(x[max_index2], y12[max_index2], color='red', s=k)

axs[0].plot(x, y13, label='ACC', color='green', linewidth=line)
max_index3 = np.argmax(y13)
axs[0].scatter(x[max_index3], y13[max_index3], color='red', s=k)

axs[0].plot(x, y14, label='F1', color='lightcoral', linewidth=line)
max_index4 = np.argmax(y14)
axs[0].scatter(x[max_index4], y14[max_index4], color='red', s=k)
axs[0].legend()
axs[0].set_title('DBLP', fontsize=plt.rcParams['font.size'] * 1.1)
axs[0].set_xticks(x)  # 设置x轴刻度
# axs[0].set_ylim(90, 98)

# 绘制第二个子图
axs[1].plot(x, y21, label='NMI', color='blue', linewidth=line)
max_index1 = np.argmax(y21)
axs[1].scatter(x[max_index1], y21[max_index1], color='red', s=k)

axs[1].plot(x, y22, label='ARI', color='orange', linewidth=line)
max_index2 = np.argmax(y22)
axs[1].scatter(x[max_index2], y22[max_index2], color='red', s=k)

axs[1].plot(x, y23, label='ACC', color='green', linewidth=line)
max_index3 = np.argmax(y23)
axs[1].scatter(x[max_index3], y23[max_index3], color='red', s=k)

axs[1].plot(x, y24, label='F1', color='lightcoral', linewidth=line)
max_index4 = np.argmax(y24)
axs[1].scatter(x[max_index4], y24[max_index4], color='red', s=k)

axs[1].legend()
axs[1].set_title('ACM', fontsize=plt.rcParams['font.size'] * 1.1)
axs[1].set_xticks(x)  # 设置x轴刻度
# axs[1].set_xlabel(r'${d_{em}}$', fontsize=plt.rcParams['font.size'] * 1.1)  # 添加x轴标签

# 绘制第三个子图
axs[2].plot(x, y31, label='NMI', color='blue', linewidth=line)
max_index1 = np.argmax(y31)
axs[2].scatter(x[max_index1], y31[max_index1], color='red', s=k)

axs[2].plot(x, y32, label='ARI', color='orange', linewidth=line)
max_index2 = np.argmax(y32)
axs[2].scatter(x[max_index2], y32[max_index2], color='red', s=k)

axs[2].plot(x, y33, label='ACC', color='green', linewidth=line)
max_index3 = np.argmax(y33)
axs[2].scatter(x[max_index3], y33[max_index3], color='red', s=k)

axs[2].plot(x, y34, label='F1', color='lightcoral', linewidth=line)
max_index4 = np.argmax(y34)
axs[2].scatter(x[max_index4], y34[max_index4], color='red', s=k)

axs[2].legend()
axs[2].legend()
axs[2].set_title('YELP', fontsize=plt.rcParams['font.size'] * 1.1)
axs[2].set_xticks(x)  # 设置x轴刻度

# # # ##### 嵌入维度数据
# axs[0].set_xticklabels([4, 8, 16, 32, 64, 128, 256])  # 设置x轴刻度标签
# axs[0].set_yticks([40, 50, 60, 70, 80, 90])
# axs[0].set_xlabel(r'${d}$', fontsize=plt.rcParams['font.size'] * 1.1)  # 添加x轴标签
# axs[1].set_xticklabels([4, 8, 16, 32, 64, 128, 256])  # 设置x轴刻度标签
# axs[1].set_yticks([30, 40, 50, 60, 70])
# axs[1].set_xlabel(r'${d}$', fontsize=plt.rcParams['font.size'] * 1.1)  # 添加x轴标签
# axs[2].set_xticklabels([4, 8, 16, 32, 64, 128, 256])  # 设置x轴刻度标签
# axs[2].set_xlabel(r'${d}$', fontsize=plt.rcParams['font.size'] * 1.2)  # 添加x轴标签

# # ##### 参数a：结构重构
axs[0].set_xticklabels([0, 20, 40, 60, 80, 100, 120])  # 设置x轴刻度标签
axs[0].set_ylim(0, 100)
# axs[0].set_yticks([40, 50, 60, 70, 80, 90])
axs[0].set_xlabel(r'${\alpha}$', fontsize=plt.rcParams['font.size'] * 1.1)  # 添加x轴标签
axs[1].set_xticklabels([0, 20, 40, 60, 80, 100, 120])  # 设置x轴刻度标签
axs[1].set_ylim(0, 100)
# axs[1].set_yticks([30, 40, 50, 60, 70])
axs[1].set_xlabel(r'${\alpha}$', fontsize=plt.rcParams['font.size'] * 1.1)  # 添加x轴标签
axs[2].set_xticklabels([0, 20, 40, 60, 80, 100, 120])  # 设置x轴刻度标签
axs[2].set_ylim(0, 100)
axs[2].set_xlabel(r'${\alpha}$', fontsize=plt.rcParams['font.size'] * 1.2)  # 添加x轴标签


# # # ##### 参数b：属性重构
# axs[0].set_xticklabels([0, 30, 60, 90, 120, 150, 180])  # 设置x轴刻度标签
# axs[0].set_ylim(0, 100)
# axs[0].set_xlabel(r'${\beta}$', fontsize=plt.rcParams['font.size'] * 1.1)  # 添加x轴标签
# axs[1].set_xticklabels([0, 30, 60, 90, 120, 150, 180])  # 设置x轴刻度标签
# axs[1].set_xlabel(r'${\beta}$', fontsize=plt.rcParams['font.size'] * 1.1)  # 添加x轴标签
# axs[1].set_ylim(0, 100)
# axs[2].set_xticklabels([0, 30, 60, 90, 120, 150, 180])  # 设置x轴刻度标签
# axs[2].set_xlabel(r'${\beta}$', fontsize=plt.rcParams['font.size'] * 1.2)  # 添加x轴标签
# axs[2].set_ylim(0, 100)
#
#
# # # ##### 参数c：模块度最大化
# axs[0].set_xticklabels([0, 1e-5, 1e-4, 1e-3, 1e-2, 1e-1, 1])  # 设置x轴刻度标签
# axs[0].set_ylim(0, 100)
# axs[0].set_xlabel(r'${\gamma}$', fontsize=plt.rcParams['font.size'] * 1.1)  # 添加x轴标签
# axs[1].set_xticklabels([0, 0.00001, 0.0001, 0.001, 0.01, 0.1, 1])  # 设置x轴刻度标签
# axs[1].set_xlabel(r'${\gamma}$', fontsize=plt.rcParams['font.size'] * 1.1)  # 添加x轴标签
# axs[1].set_ylim(0, 100)
# axs[2].set_xticklabels([0, 0.00001, 0.0001, 0.001, 0.01, 0.1, 1])  # 设置x轴刻度标签
# axs[2].set_xlabel(r'${\gamma}$', fontsize=plt.rcParams['font.size'] * 1.2)  # 添加x轴标签
# axs[2].set_ylim(0, 100)

# 调整子图之间的间距
plt.tight_layout()

# 显示图形
plt.show()
