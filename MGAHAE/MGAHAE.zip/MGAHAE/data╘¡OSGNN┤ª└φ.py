import numpy as np
import scipy
import pickle
import torch
import dgl
import torch.nn.functional as F
import torch as th
import scipy.sparse as sp

def load_ACM_data(prefix=r'.\Dataset\ACM'):
    # ####加载了三个稀疏矩阵文件 (features_0.npz, features_1.npz, features_2.npz)，并将它们转换为稠密数组格式 (toarray() 方法)
    features_0 = scipy.sparse.load_npz(prefix + '/features_0.npz').toarray()  # 4019*4000
    features_1 = scipy.sparse.load_npz(prefix + '/features_1.npz').toarray()  # 7167*4000
    features_2 = scipy.sparse.load_npz(prefix + '/features_2.npz').toarray()  # 60*4000

    labels = np.load(prefix + '/labels.npy')  # 加载标签数据，4019个：{0, 1, 2}
    train_val_test_idx = np.load(prefix + '/train_val_test_idx.npz')  # 加载训练、验证和测试索引

    PAP = scipy.sparse.load_npz(prefix + '/pap.npz').A  # 加载稀疏矩阵，.A将稀疏矩阵转为稠密矩阵
    PAP = torch.from_numpy(PAP).type(torch.FloatTensor)  # 将它们转换为 PyTorch 的 FloatTensor 类型
    PAP = F.normalize(PAP, dim=1, p=2)  # 并使用 PyTorch 的 F.normalize 函数对每行进行 L2 归一化

    PSP = scipy.sparse.load_npz(prefix + '/psp.npz').A
    PSP = torch.from_numpy(PSP).type(torch.FloatTensor)
    PSP = F.normalize(PSP, dim=1, p=2)
    #  #最后，将这些归一化后的张量存储在列表 G 中
    G = [PAP, PSP]
    #  #加载并处理图的邻接矩阵
    ADJ = scipy.sparse.load_npz(prefix + '/adjM.npz')  # 加载稀疏邻接矩阵数据，节点数：11246；边数：
    ADJ = dgl.DGLGraph(ADJ + (ADJ.T))  # 将其转换为 dgl.DGLGraph 对象
    # ADJ = dgl.graph(ADJ + (ADJ.T))
    ADJ = dgl.remove_self_loop(ADJ)  # remove_self_loop 和 add_self_loop 方法分别移除和添加自环边，以确保每个节点都有一个自环。
    ADJ = dgl.add_self_loop(ADJ)

    features_0 = torch.FloatTensor(features_0)  # 将ndarray特征数据格式转换为Tensor格式
    features_1 = torch.FloatTensor(features_1)
    features_2 = torch.FloatTensor(features_2)
    features = [features_0, features_1, features_2]

    labels = torch.LongTensor(labels)
    type_mask = np.load(prefix + '/node_types.npy')  # 加载节点类型，11246个：{0, 1, 2}

    num_classes = 3
    train_idx = train_val_test_idx['train_idx']  # 训练集：400
    val_idx = train_val_test_idx['val_idx']  # 验证集：400
    test_idx = train_val_test_idx['test_idx']  # 测试集：3219

    return G, ADJ, features, labels, num_classes, train_idx, val_idx, test_idx, type_mask
# ## G: [tensor(4019,4019),tensor(4019,4019)]表示元路径子图； ADJ：原图的邻接矩阵的DGLGraph格式； labels：tensor(4019)目标节点标签
# ## num_classes：3 ； train_idx: ndarray[400]; val_idx: ndarray[400]; test_idx: ndarray[3219];
# ## type_mask: ndarray[11246]; features: [tensor(4019,4000),tensor(7167,4000),tensor(60,4000)].

def load_IMDB_data(prefix=r'.\Dataset\IMDB'):
    features_0 = scipy.sparse.load_npz(prefix + '/features_0.npz').toarray()
    features_1 = scipy.sparse.load_npz(prefix + '/features_1.npz').toarray()
    features_2 = scipy.sparse.load_npz(prefix + '/features_2.npz').toarray()

    labels = np.load(prefix + '/labels.npy')
    train_val_test_idx = np.load(prefix + '/train_val_test_idx.npz')

    MAM = np.load(prefix + '/mam.npy')
    MAM = torch.from_numpy(MAM).type(torch.FloatTensor)
    MAM = F.normalize(MAM, dim=1, p=2)

    MDM = np.load(prefix + '/mdm.npy')
    MDM = torch.from_numpy(MDM).type(torch.FloatTensor)
    MDM = F.normalize(MDM, dim=1, p=2)

    G = [MAM, MDM]

    ADJ = scipy.sparse.load_npz(prefix + '/adjM.npz')
    ADJ = dgl.DGLGraph(ADJ + (ADJ.T))
    ADJ = dgl.remove_self_loop(ADJ)
    ADJ = dgl.add_self_loop(ADJ)

    features_0 = torch.FloatTensor(features_0)
    features_1 = torch.FloatTensor(features_1)
    features_2 = torch.FloatTensor(features_2)
    features = [features_0, features_1, features_2]

    labels = torch.LongTensor(labels)
    type_mask = np.load(prefix + '/node_types.npy')

    num_classes = 3
    train_idx = train_val_test_idx['train_idx']
    val_idx = train_val_test_idx['val_idx']
    test_idx = train_val_test_idx['test_idx']

    return G, ADJ, features, labels, num_classes, train_idx, val_idx, test_idx, type_mask



def load_DBLP_data(prefix=r'.\Dataset\DBLP'):
    features_0 = scipy.sparse.load_npz(prefix + '/features_0.npz').toarray()
    features_1 = scipy.sparse.load_npz(prefix + '/features_1.npz').toarray()
    features_2 = np.load(prefix + '/features_2.npy')
    features_3 = np.eye(20)

    labels = np.load(prefix + '/labels.npy')

    nd_APA = scipy.sparse.load_npz(prefix + '/apa.npz').A
    nd_APTPA = scipy.sparse.load_npz(prefix + '/aptpa.npz').A
    nd_APCPA = scipy.sparse.load_npz(prefix + '/apvpa.npz').A

    # nd_APA[nd_APA != 0] = 1
    # nd_APTPA[nd_APTPA != 0] = 1
    # nd_APCPA[nd_APCPA != 0] = 1
    #
    # APA = nd_APA
    # APTPA = nd_APTPA
    # APCPA = nd_APCPA

    # apa_g = dgl.from_scipy(sp.csr_matrix(nd_APA))
    # apcpa_g = dgl.from_scipy(sp.csr_matrix(nd_APTPA))
    # aptpa_g = dgl.from_scipy(sp.csr_matrix(nd_APCPA))
    # gs = [apa_g, apcpa_g, aptpa_g]  # 1、元路径子图

    APA = torch.from_numpy(nd_APA).type(torch.FloatTensor)
    APA = F.normalize(APA, dim=1, p=2)

    APTPA = torch.from_numpy(nd_APTPA).type(torch.FloatTensor)
    APTPA = F.normalize(APTPA, dim=1, p=2)

    APCPA = torch.from_numpy(nd_APCPA).type(torch.FloatTensor)
    APCPA = F.normalize(APCPA, dim=1, p=2)

    numpy_APA = APA.numpy()
    numpy_APA_float64 = numpy_APA.astype(np.float64)
    numpy_APTPA = APTPA.numpy()
    numpy_APTPA_float64 = numpy_APTPA.astype(np.float64)
    numpy_APCPA = APCPA.numpy()
    numpy_APCPA_float64 = numpy_APCPA.astype(np.float64)

    apa_g = dgl.from_scipy(sp.csr_matrix(numpy_APA_float64))
    apcpa_g = dgl.from_scipy(sp.csr_matrix(numpy_APTPA_float64))
    aptpa_g = dgl.from_scipy(sp.csr_matrix(numpy_APCPA_float64))
    gs = [apa_g, apcpa_g, aptpa_g]  # 1、元路径子图

    adj = 0.8 * APA + 0.35 * APTPA + 0.25 * APCPA
    adj = torch.Tensor(adj)
    adj = (adj - torch.min(adj)) / (torch.max(adj) - torch.min(adj))  # 5、同构图

    ADJ = scipy.sparse.load_npz(prefix + '/adjM.npz')
    ADJ = dgl.DGLGraph(ADJ + (ADJ.T))
    ADJ = dgl.remove_self_loop(ADJ)
    ADJ = dgl.add_self_loop(ADJ)

    features_0 = torch.FloatTensor(features_0)  # 2、目标节点特征
    features_1 = torch.FloatTensor(features_1)
    features_2 = torch.FloatTensor(features_2)
    features_3 = torch.FloatTensor(features_3)
    features = [features_0, features_1, features_2, features_3]

    labels = torch.LongTensor(labels)  # 3、标签
    type_mask = np.load(prefix + '/node_types.npy')  # 节点类型的掩码

    num_classes = 4  # 标签类属

    return gs, features_0, labels, num_classes, adj

