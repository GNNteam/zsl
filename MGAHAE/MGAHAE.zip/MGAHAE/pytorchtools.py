import numpy as np
import torch


class EarlyStopping:
    """Early stops the training if validation loss doesn't improve after a given patience."""
    def __init__(self, patience, verbose=False, delta=0.0005, save_path='checkpoint.pt'):
        """
        Args:
            patience (int): How long to wait after last time validation loss improved.
                            Default: 7
            verbose (bool): If True, prints a message for each validation loss improvement.
                            Default: False
            delta (float): Minimum change in the monitored quantity to qualify as an improvement.
                            Default: 0
        """
        self.patience = patience
        self.verbose = verbose
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.val_loss_min = np.Inf
        self.delta = delta
        self.save_path = save_path

    def __call__(self, val_loss, model):

        score = val_loss

        if self.best_score is None:
            self.best_score = score  # 当前验证损失的负数
            self.save_checkpoint(val_loss, model)  # 保存打印损失最小时的损失与模型
        elif score >= self.best_score - self.delta:  # 新损失不小于最小损失，进入。self.delta为容差
            self.counter += 1
            print('EarlyStopping counter: {} / {}'.format(self.counter, self.patience))
            if self.counter >= self.patience:  #
                self.early_stop = True
        else:
            self.best_score = score  # 当前验证损失的负数
            self.save_checkpoint(val_loss, model)  # 保存打印损失最小时的损失与模型
            self.counter = 0

    def save_checkpoint(self, val_loss, model):
        """Saves model when validation loss decrease."""
        if self.verbose:  # 打印之前保存的最小验证损失，val_loss 是当前的验证损失
            print('Validation loss decreased ({:.6f} --> {:.6f}).  Saving model ...'.format(self.val_loss_min, val_loss))
        torch.save(model.state_dict(), self.save_path)  # 使用 PyTorch 的 torch.save 函数保存模型的状态字典到文件系统中。
        self.val_loss_min = val_loss
