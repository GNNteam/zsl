import matplotlib.pyplot as plt
import numpy as np

# 设置全局字体大小
plt.rcParams['font.size'] = 15

data1 = np.array([
    [94.43, 92.5, 85.69, 90.53, 93.36],
    [94.11, 94.35, 93.45, 93.66, 96.08],
    [87.32, 96.77, 95.83, 84.24, 96.73]
])

data2 = np.array([
    [94.81, 93.00, 81.8, 90.97, 93.91],
    [94.04, 94.26, 93.38, 93.60, 96.03],
    [88.93, 96.56, 95.04, 85.11, 96.18],
])

# 行名
labels = ['DBLP', 'ACM', 'Yelp']

# 列名
categories = ['MGAG-f', 'MGAG-o', 'MGAG-s', 'MGAG-mean', 'MGAG']

# 设置柱状图参数
bar_width = 0.15  # 调整柱状图宽度

# 设置绘图分辨率为1200dpi
fig = plt.figure(figsize=(8, 3), dpi=200)

# 绘制第一个子图
plt.subplot(121)

bar_positions = np.arange(len(labels)) - bar_width * 2  # 调整柱状图位置
colors = ['steelblue', 'Darkorange', 'darkgrey', 'orange', 'deepskyblue']
for i in range(len(categories)):
    plt.bar(bar_positions + i * bar_width, data1[:, i] - 75, bar_width, label=categories[i], color=colors[i])

plt.ylabel('Macro-F1')
plt.yticks(np.arange(0, 26, 5), np.arange(75, 101, 5))

# 设置 x 轴标签，并旋转为垂直方向
plt.xticks(np.arange(len(labels)), labels)

# 调整图例位置，分成两列
plt.legend(loc='upper center', bbox_to_anchor=(1, 1.35), ncol=3)

# 绘制第二个子图
plt.subplot(122)

bar_positions = np.arange(len(labels)) - bar_width * 2  # 调整柱状图位置
for i in range(len(categories)):
    plt.bar(bar_positions + i * bar_width, data2[:, i] - 75, bar_width, label=categories[i], color=colors[i])

plt.ylabel('Micro-F1')
plt.yticks(np.arange(0, 26, 5), np.arange(75, 101, 5))

# 设置 x 轴标签，并旋转为垂直方向
plt.xticks(np.arange(len(labels)), labels)

# 调整图例位置，分成两列
# plt.legend(loc='upper center', bbox_to_anchor=(0.5, 1.2), ncol=2)

plt.show()
