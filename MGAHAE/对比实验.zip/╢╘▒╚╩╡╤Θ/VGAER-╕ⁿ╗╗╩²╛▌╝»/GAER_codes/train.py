from __future__ import division
from __future__ import print_function

import argparse
import time
import networkx as nx
import numpy as np
import scipy.sparse as sp
import torch
from torch import optim
import pandas as pd
# import scanpy
import csv
from Qvalue import Q
from dgl.data import CoraGraphDataset, CiteseerGraphDataset , PubmedGraphDataset
from data import load_ACM_data, load_DBLP_data, load_ourACM3025, load_YELP

from model import GAER
# from optimizer import loss_function
# import torch.nn.modules.loss
import torch.nn.functional as F
# from algorithm

from cluster import community
from NMI import load_label, NMI, label_change
from sklearn import metrics
# from Qvalue import Q
# from tsne import get_data,tsne_show
# from Qwepoch import Q_with_epoch

figcount = 0
parser = argparse.ArgumentParser()
parser.add_argument('--model', type=str, default='gcn_vae', help="models used")
parser.add_argument('--seed', type=int, default=42, help='Random seed.')
parser.add_argument('--epochs', type=int, default=50, help='Number of epochs to train.')
parser.add_argument('--hidden1', type=int, default=64, help='Number of units in hidden layer 1.')
parser.add_argument('--hidden2', type=int, default=32, help='Number of units in hidden layer 2.')
parser.add_argument('--lr', type=float, default=0.01, help='Initial learning rate.')
parser.add_argument('--dropout', type=float, default=0., help='Dropout rate (1 - keep probability).')
parser.add_argument('--dataset', type=str, default='DBLP', help='type of dataset.')
parser.add_argument('--cluster', type=str, default=7, help='Number of community')


args = parser.parse_args()
use_cuda = torch.cuda.is_available()
device = torch.device("cuda" if use_cuda else "cpu")

def gaer_for(args):

    if args.dataset == 'DBLP':
        features, labels, num_classes, adj = load_DBLP_data()
    elif args.dataset == 'ACM':
        features, labels, num_classes, adj = load_ourACM3025()
    elif args.dataset == 'YELP':
        features, labels, num_classes, adj = load_YELP()
    else:
        raise NotImplementedError
    A = adj  # Tensor邻接矩阵
    args.cluster = num_classes
    label_orig = labels.detach().numpy()  # ndarray一维标签

    K = 1 / (A.sum().item()) * (A.sum(dim=1).reshape(A.shape[0], 1) @ A.sum(dim=1).reshape(1, A.shape[0]))
    B = A - K  # 文中公式2
    B = B.to(device)

    features = features.to(device)
    feats = torch.cat((features, B), 1)  # 将特征与模块度矩阵拼接
    in_dim = feats.shape[-1]

    A = A + torch.eye(A.shape[0])  # 邻接矩阵加自环
    D = torch.diag(torch.pow(A.sum(dim=1), -0.5))  # D = D^-1/2
    A_hat = D @ A @ D  # 度归一化
    A_hat = A_hat.to(device)
    n_nodes, feat_dim = features.shape

    model = GAER(feat_dim, args.hidden1, args.hidden2, args.dropout)
    model.to(device)
    opt = optim.Adam(model.parameters(), lr=args.lr)
    # nmi=[]

    def cluster_acc(y_true, y_pred):
        y_true = y_true - np.min(y_true)

        l1 = list(set(y_true))
        numClass1 = len(l1)

        l2 = list(set(y_pred))
        numClass2 = len(l2)

        ind = 0
        if numClass1 != numClass2:
            for i in l1:
                if i in l2:
                    pass
                else:
                    y_pred[ind] = i
                    ind += 1

        l2 = list(set(y_pred))
        numClass2 = len(l2)

        if numClass1 != numClass2:
            print("error")
            return

        cost = np.zeros((numClass1, numClass2), dtype=int)
        for i, c1 in enumerate(l1):
            mps = [i1 for i1, e1 in enumerate(y_true) if e1 == c1]
            for j, c2 in enumerate(l2):
                mps_d = [i1 for i1 in mps if y_pred[i1] == c2]
                cost[i][j] = len(mps_d)

        from munkres import Munkres
        # match two clustering results by Munkres algorithm
        m = Munkres()
        cost = cost.__neg__().tolist()
        indexes = m.compute(cost)

        # get the match results
        new_predict = np.zeros(len(y_pred))
        for i, c in enumerate(l1):
            # corresponding label in l2:
            c2 = l2[indexes[i][1]]

            # ai is the index with label==c2 in the pred_label list
            ai = [ind for ind, elm in enumerate(y_pred) if elm == c2]
            new_predict[ai] = c

        # 预测标签处理后，得到的指标都有提升。
        acc = metrics.accuracy_score(y_true, new_predict)
        f1_macro = metrics.f1_score(y_true, new_predict, average="macro")
        return acc, f1_macro

    for epoch in range(args.epochs):

        model.train()
        opt.zero_grad()
        recovered = model(A_hat=A_hat, x=features)  # 输入: 邻接矩阵与特征.  输出:（1）2708*32的嵌入；（2）2708*2708的重构矩阵
        loss = F.mse_loss(input=recovered[1], target=B)  # 计算了重构矩阵和真实矩阵B之间的均方误差

        # loss = F.binary_cross_entropy_with_logits(input=F.sigmoid(recovered[1]), target=B)
        cur_loss = loss.item()
        print("Epoch:", '%04d' % (epoch + 1), "train_loss=", "{:.5f}".format(cur_loss))
        loss.backward()
        opt.step()
        model.eval()

        hidemb = recovered[0].cpu()  # 将2708*32的嵌入放入CPU
        # hidemb = hidemb.cpu()
        commu_pred = community(hidemb, args.cluster)  # 根据隐藏特征 hidemb 和指定的聚类数 args.cluster 进行社区检测
        nmi = NMI(commu_pred, label_orig)
        ari = metrics.adjusted_rand_score(label_orig, commu_pred)
        acc, f1_macro = cluster_acc(label_orig, commu_pred)
        print("第{}次epoch :NMI {} | Ari {:.4f}| Acc {:.4f} | F1_macro {:.4f}".format(
            epoch, nmi, ari, acc, f1_macro))

        if epoch == args.epochs - 1:
            hidemb = recovered[0].cpu()  # 将2708*32的嵌入放入CPU
            # hidemb = hidemb.cpu()
            commu_pred = community(hidemb, args.cluster)  # 根据隐藏特征 hidemb 和指定的聚类数 args.cluster 进行社区检测
            # Q_NUMBER = []
            # for i in range(5, args.cluster):
            #     commu_pred = community(hidemb, i)
            #     Q_NUMBER.append(Q(A_orig, np.eye(args.cluster)[commu_pred]))
            # print(Q_NUMBER)

            # NMI(commu_pred, label_orig)

            nmi = NMI(commu_pred, label_orig)
            ari = metrics.adjusted_rand_score(label_orig, commu_pred)
            acc, f1_macro = cluster_acc(label_orig, commu_pred)
            print("Final result_Kmeans :NMI {} | Ari {:.4f}| Acc {:.4f} | F1_macro {:.4f}".format(
                nmi, ari, acc, f1_macro))

        # hidemb = recovered[0].cpu()
        # hidemb = hidemb.detach().numpy()
        commu_pred = community(hidemb, args.cluster)
        # #
        # # # nminew=NMI(commu_pred, label_orig)
        # Q(A_orig, np.eye(args.cluster)[np.array(commu_pred)])
        # Q_value.append(Qnew)
        # nmi.append(nminew)

        # if epoch == args.epochs - 1:
        #     # Q_with_epoch(args.epochs, Q_value)
        #     # tsne_show(hidemb, commu_pred,figcount)
        #     commu_pred = community(hidemb, args.cluster)
        #     label_orig = load_label(args.dataset_str)[0]
        #     commu_pred2 = label_change(commu_pred, label_orig)
            # NMI(commu_pred2, label_orig)
            # for qi in range(5, 10):
            #     hidemb = recovered[0].detach().numpy()
            #     commu_pred = community(hidemb, qi)
            #     Q(A_orig, np.eye(qi)[np.array(commu_pred)])
        #
        # with open('karate_NMI500gaer.csv','a',encoding='utf-8', newline='') as csvfile:
        #     fieldnames = ['epoch', 'Qvalue']
        #     writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        #     writer.writerow({'epoch': epoch, 'Qvalue': Qnew})
        # # with open('hidemb_gaer500(2).csv','a',encoding='utf-8', newline='') as csvfile:
        #     fieldnames = ['epoch', 'hidemb']
        #     writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        #     writer.writerow({'epoch': epoch, 'hidemb': hidemb})


        # print('每个人的预测类别：', torch.Tensor(commu_pred2))
        # print('准确率：', float((torch.Tensor(commu_pred2) == adj_label).sum()) / A.shape[0])

        # tsne_show(hidemb, commu_pred2)

    print("Optimization Finished!")


if __name__ == '__main__':
        gaer_for(args)







