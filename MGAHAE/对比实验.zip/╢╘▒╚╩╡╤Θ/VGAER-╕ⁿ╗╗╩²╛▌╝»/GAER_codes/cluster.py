from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import numpy as np
from sklearn.manifold import TSNE

# def community (z,clusters):
#     z = z.detach().numpy()  # z: ndarray(2708*32)
#     C_model = KMeans(n_clusters=clusters, verbose=0, max_iter=100, tol=0.01, n_init=3)  # clusters：指定聚类数量。
#     # # verbose=1：在训练过程中输出详细信息。max_iter=100：最大迭代次数为100。tol=0.01：容忍度，收敛条件。n_init=3：运行 KMeans 的初始种子数。
#     C_model.fit(z)  # 使用 KMeans 模型对数据 z 进行训练
#
#     # train label
#     commu_predict = C_model.labels_  # 从 KMeans 模型中获取每个数据点的聚类标签，存储在 commu_predict 中。
#
#     centers = C_model.cluster_centers_  # 获取聚类中心
#     # centers_id = []
#     # for i in range(clusters):
#     #     centers_id.append(int(np.argwhere(z==centers[i])[0]))
#     distance = C_model.inertia_  # 表示数据点与其聚类中心的距离之和
#     iterations = C_model.n_iter_  # 获取模型实际进行的迭代次数
#     # print("ceners = ", centers)
#     # print("distance = ", distance)
#     # print("iterations = ", iterations)
#
#     # plt.figure(figsize=(8,3), dpi=120)
#     #
#     # #（1）orgin
#     # plt.subplot(1, 2, 1)  # 画布分为1行，2列，共2格，当前绘图区设定为第1格
#     # plt.scatter(z[:, 0], z[:, 1], c="blue", marker='o', s=10)  # 形状是圆圈；圆圈大小是10；颜色是蓝色
#     # plt.title("cora")
#     # plt.subplot(1, 2, 2)  # 当前绘图区设定为第2格
#     # plt.scatter(z[:, 0], z[:, 1], c=commu_predict, marker='o', s=10)  # 不同类别不同颜色
#     # plt.title("k-means")
#     return commu_predict


def community (z1, clusters):
    z1 = z1.detach().numpy()
    #for i in range(1,11):
    #ts = manifold.TSNE(n_components=2, perplexity=3, early_exaggeration=10, n_iter=50000, learning_rate=500,  angle=0.5, init='random')
    ts = TSNE(n_components=2, perplexity=50, early_exaggeration=500, n_iter=10000, learning_rate=50, angle=0.5,
                       init='random')  # 开始时， n_iter=100000，learning_rate=100
    z = ts.fit_transform(z1)  # 这一步运行较慢，需更改
    #C_model = KMeans(n_clusters=clusters, verbose=0, max_iter=1000, tol=0.001, n_init=20, init='k-means++')
    C_model = KMeans(n_clusters=clusters, verbose=0, max_iter=1000, tol=0.001, n_init=20, init='k-means++')
    #C_model = KMeans(n_clusters=clusters, verbose=0, max_iter=100, tol=0.01, n_init=3)
    C_model.fit(z)
    commu_predict = C_model.labels_
    #torch.save(commu_predict, './pred.pt')
    plt.figure(figsize=(10, 10), dpi=80)
    z = plt.scatter(z[:, 0], z[:, 1], c=commu_predict, marker='o', s=10)  # 不同类别不同颜色
    plt.title("k-means")
    #plt.savefig('./cora{}.pdf'.format(i))
    plt.show()
    # print(i)
    return commu_predict
