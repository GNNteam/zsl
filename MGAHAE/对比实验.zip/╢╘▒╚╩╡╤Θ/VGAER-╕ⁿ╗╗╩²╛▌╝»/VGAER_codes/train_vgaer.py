from __future__ import division
from __future__ import print_function

import argparse
import time
import networkx as nx
import numpy as np
import scipy.sparse as sp
import torch
from matplotlib import pyplot as plt
from torch import optim
import pandas as pd
import dgl
from dgl.data import CoraGraphDataset, CiteseerGraphDataset , PubmedGraphDataset
import csv
# import scanpy

import model
from model import VGAERModel
import torch.nn.functional as F
from cluster import community
from NMI import load_label, NMI, label_change
from Qvalue import Q
from sklearn import manifold
from sklearn import metrics
from data import load_ACM_data, load_DBLP_data, load_ourACM3025, load_YELP
#from tsne import get_data,tsne_show
#from Qwepoch import Q_with_epoch
from sklearn.manifold import TSNE

parser = argparse.ArgumentParser()
parser.add_argument('--model', type=str, default='gcn_vae', help="models used")
parser.add_argument('--seed', type=int, default=42, help='Random seed.')
parser.add_argument('--epochs', type=int, default=5, help='Number of epochs to train.')  # 原：500
parser.add_argument('--hidden1', type=int, default=8, help='Number of units in hidden layer 1.')
parser.add_argument('--hidden2', type=int, default=2, help='Number of units in hidden layer 2.')
parser.add_argument('--lr', type=float, default=0.05, help='Initial learning rate.')
parser.add_argument('--dropout', type=float, default=0., help='Dropout rate (1 - keep probability).')
parser.add_argument('--dataset', type=str, default='ACM', help='type of dataset.')
parser.add_argument('--cluster', type=str, default=7, help='Number of community')
args = parser.parse_args()

#Check device
use_cuda = torch.cuda.is_available()
device = torch.device("cuda" if use_cuda else "cpu")


def cluster_acc(y_true, y_pred):
    y_true = y_true - np.min(y_true)

    l1 = list(set(y_true))
    numClass1 = len(l1)

    l2 = list(set(y_pred))
    numClass2 = len(l2)

    ind = 0
    if numClass1 != numClass2:
        for i in l1:
            if i in l2:
                pass
            else:
                y_pred[ind] = i
                ind += 1

    l2 = list(set(y_pred))
    numClass2 = len(l2)

    if numClass1 != numClass2:
        print("error")
        return

    cost = np.zeros((numClass1, numClass2), dtype=int)
    for i, c1 in enumerate(l1):
        mps = [i1 for i1, e1 in enumerate(y_true) if e1 == c1]
        for j, c2 in enumerate(l2):
            mps_d = [i1 for i1 in mps if y_pred[i1] == c2]
            cost[i][j] = len(mps_d)

    from munkres import Munkres
    # match two clustering results by Munkres algorithm
    m = Munkres()
    cost = cost.__neg__().tolist()
    indexes = m.compute(cost)

    # get the match results
    new_predict = np.zeros(len(y_pred))
    for i, c in enumerate(l1):
        # corresponding label in l2:
        c2 = l2[indexes[i][1]]

        # ai is the index with label==c2 in the pred_label list
        ai = [ind for ind, elm in enumerate(y_pred) if elm == c2]
        new_predict[ai] = c

    # 预测标签处理后，得到的指标都有提升。
    acc = metrics.accuracy_score(y_true, new_predict)
    f1_macro = metrics.f1_score(y_true, new_predict, average="macro")
    return acc, f1_macro

def vgaer():
    # Load form DGL dataset
    if args.dataset == 'DBLP':
        features, labels, num_classes, adj = load_DBLP_data()
    elif args.dataset == 'ACM':
        features, labels, num_classes, adj = load_ourACM3025()
    elif args.dataset == 'YELP':
        features, labels, num_classes, adj = load_YELP()
    else:
        raise NotImplementedError
    A = adj  # Tensor邻接矩阵
    args.cluster = num_classes
    label_orig = labels.detach().numpy()  # ndarray一维标签

    A_orig = A.detach().numpy()
    A_orig_ten = A.to(device)

    #compute B matrix
    K = 1 / (A.sum().item()) * (A.sum(dim=1).reshape(A.shape[0], 1) @ A.sum(dim=1).reshape(1, A.shape[0]))
    B = A - K
    B = B.to(device)


    #compute A_hat matrix
    A = A + torch.eye(A.shape[0])
    D = torch.diag(torch.pow(A.sum(dim=1), -0.5))  # D = D^-1/2
    A_hat = D @ A @ D
    A_hat = A_hat.to(device)
    A = A.to(device)

    feats = B
    # feats = features
    in_dim = feats.shape[-1]



    #create model
    vgaer_model = model.VGAERModel(in_dim,args.hidden1,args.hidden2,device)
    vgaer_model = vgaer_model.to(device)


    #create training component
    optimizer = torch.optim.Adam(vgaer_model.parameters(),lr=args.lr)
    print('Total Parameters:', sum([p.nelement() for p in vgaer_model.parameters()]))

    def compute_loss_para(adj):
        pos_weight = ((adj.shape[0] * adj.shape[0] - adj.sum()) / adj.sum())
        norm = adj.shape[0] * adj.shape[0] / float((adj.shape[0] * adj.shape[0] - adj.sum()) * 2)
        weight_mask = adj.view(-1) == 1
        weight_tensor = torch.ones(weight_mask.size(0)).to(device)
        weight_tensor[weight_mask] = pos_weight
        return weight_tensor,norm

    weight_tensor, norm = compute_loss_para(A)

        #create traing epoch
    for epoch in range(args.epochs):
        #x_num = []
        #y_num = []
        vgaer_model.train()
        recovered = vgaer_model.forward(A_hat, feats)
        logits = recovered[0]
        hidemb = recovered[1]
        loss = norm*F.binary_cross_entropy(logits.view(-1),A_orig_ten.view(-1),weight=weight_tensor)  # 交叉熵损失
        kl_divergence = 0.5 / logits.size(0) * (
                1 + 2 * (vgaer_model.log_std + 1e-6) - vgaer_model.mean ** 2 - torch.exp(vgaer_model.log_std + 1e-6)
                ** 2).sum(1).mean()  # KL散度, 计算时需要标准差，但是loss波动过大，导致KL散度的值为: inf
        loss -= kl_divergence
        print("Epoch:", '%04d' % (epoch + 1), "train_loss=", "{:.4f}".format(loss.item()))
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        if epoch == args.epochs-1:
            hidemb = hidemb.cpu()
            #torch.save(hidemb, './z.pt')
            # NMI_count=[]
            #commu_pred = community(hidemb, args.cluster)
            # label_orig = load_label(args.dataset)[0]
            #for i in range(18,args.cluster):
            #for i in range(5):
            commu_pred = community(hidemb, args.cluster)
            #print(i)
            #hidemb = hidemb.detach().numpy()
            #hidemb = hidemb.tolist()
            #showPicture(hidemb, commu_pred)
            #lable_truepred = label_change(commu_pred, label_orig)
            # feats = feats.cpu()
            # plt.scatter(feats[:, 0], feats[:, 1], c=commu_pred)
            # plt.show()
            #feats = feats.cpu()
            # Q(A_orig, np.eye(args.cluster)[commu_pred])
            # print(Q_NUMBER)

            nmi = NMI(commu_pred, label_orig)
            ari = metrics.adjusted_rand_score(label_orig, commu_pred)
            acc, f1_macro = cluster_acc(label_orig, commu_pred)
            print("Final result_Kmeans :NMI {} | Ari {:.4f}| Acc {:.4f} | F1_macro {:.4f}".format(
                nmi, ari, acc, f1_macro))

            #x_num.append(epoch)
            #y_num.append(nmi * 100)
            # ts = manifold.TSNE(n_components=2, perplexity=35, early_exaggeration=500, n_iter=2000, learning_rate=500,
            #                    angle=0.5, init='random')
            # # ts = manifold.TSNE(n_components=2)
            # hidemb = hidemb.detach().numpy()
            # z = ts.fit_transform(hidemb)
            # # C_model = KMeans(n_clusters=clusters, verbose=0, max_iter=1000, tol=0.001, n_init=20, init='k-means++')
            # plt.figure(figsize=(8, 8), dpi=120)
            # plt.scatter(z[:, 0], z[:, 1], c=commu_pred, marker='o', s=5)  # 不同类别不同颜色
            # plt.title("k-means")
            # plt.show()
    # np.save('./{}_epoch_x.npy'.format(args.dataset), x_num)
    # np.save('./{}_epoch_y.npy'.format(args.dataset), y_num)
if __name__ == '__main__':
    vgaer()

















