import numpy as np
import scipy
import pickle
import torch
import dgl
import torch.nn.functional as F
import torch as th
import scipy.sparse as sp
import random
import datetime
import os

def load_ACM_data(prefix=r'.\Dataset\ACM'):
    # ####加载了三个稀疏矩阵文件 (features_0.npz, features_1.npz, features_2.npz)，并将它们转换为稠密数组格式 (toarray() 方法)
    features_0 = scipy.sparse.load_npz(prefix + '/features_0.npz').toarray()  # 4019*4000

    labels = np.load(prefix + '/labels.npy')  # 加载标签数据，4019个：{0, 1, 2}

    PAP = scipy.sparse.load_npz(prefix + '/pap.npz').A  # 加载稀疏矩阵，.A将稀疏矩阵转为稠密矩阵
    PSP = scipy.sparse.load_npz(prefix + '/psp.npz').A

    adj = PAP + PSP
    adj = torch.Tensor(adj)
    adj = (adj - torch.min(adj)) / (torch.max(adj) - torch.min(adj))  # 5、同构图

    features_0 = torch.FloatTensor(features_0)  # 将ndarray特征数据格式转换为Tensor格式

    labels = torch.LongTensor(labels)

    num_classes = 3

    return features_0, labels, num_classes, adj

def load_DBLP_data(prefix='D:\A1论文实验过程\对比实验\VGAER-更换数据集\dataset\DBLP'):
    features_0 = scipy.sparse.load_npz(prefix + '/features_0.npz').toarray()

    labels = np.load(prefix + '/label.npy')

    nd_APA = scipy.sparse.load_npz(prefix + '/apa.npz').A
    nd_APTPA = scipy.sparse.load_npz(prefix + '/aptpa.npz').A
    nd_APCPA = scipy.sparse.load_npz(prefix + '/apvpa.npz').A

    nd_APA[nd_APA != 0] = 1
    nd_APTPA[nd_APTPA != 0] = 1
    nd_APCPA[nd_APCPA != 0] = 1

    APA = nd_APA
    APTPA = nd_APTPA
    APCPA = nd_APCPA

    # adj = 0.8 * APA + 0.35 * APTPA + 0.25 * APCPA
    adj = 0.8/1.4 * APA + 0.35/1.4 * APTPA + 0.25/1.4 * APCPA
    adj = torch.Tensor(adj)
    adj = (adj - torch.min(adj)) / (torch.max(adj) - torch.min(adj))  # 5、同构图

    features_0 = torch.FloatTensor(features_0)  # 2、目标节点特征

    labels = torch.LongTensor(labels)  # 3、标签

    num_classes = 4  # 标签类属

    return features_0, labels, num_classes, adj

def load_ourACM3025(prefix=r'D:\A1论文实验过程\对比实验\VGAER-更换数据集\dataset\MGAG_ACM3025'):
    # 从 .pkl 文件读取数据
    with open(prefix + '/feature.pkl', 'rb') as f:
        features = pickle.load(f)

    labels = np.load(prefix + '/label.npy')
    features_0 = features[0].numpy()

    nd_PAP = np.load(prefix + '/pap.npy')
    nd_PSP = np.load(prefix + '/psp.npy')
    nd_PAPSP = np.load(prefix + '/papsp.npy')
    nd_PSPAP = np.load(prefix + '/pspap.npy')

    nd_PAP[nd_PAP != 0] = 1
    nd_PSP[nd_PSP != 0] = 1
    nd_PAPSP[nd_PAPSP != 0] = 1
    nd_PSPAP[nd_PSPAP != 0] = 1

    PAP = nd_PAP
    PSP = nd_PSP
    PAPSP = nd_PAPSP
    PSPAP = nd_PSPAP

    adj = PAP + PSP + PAPSP + PSPAP
    # adj = 0.55 * PAP + 0.45 * PSP
    adj = torch.Tensor(adj)
    adj = (adj - torch.min(adj)) / (torch.max(adj) - torch.min(adj))  # 5、同构图

    labels = torch.LongTensor(labels)  # 3、标签

    num_classes = 3  # 标签类属

    return features[0], labels, num_classes, adj

def load_YELP(prefix=r'D:\A1论文实验过程\对比实验\VGAER-更换数据集\dataset\YELP'):
    # 从 .pkl 文件读取数据
    with open(prefix + '/feature.pkl', 'rb') as f:
        features = pickle.load(f)

    labels = np.load(prefix + '/label.npy')

    nd_BUB = np.load(prefix + '/BUB.npy')  # 是无向图
    nd_BSB = np.load(prefix + '/BSB.npy')  # 是无向图
    nd_BUBSB = np.load(prefix + '/BUBSB.npy')  # 是无向图
    nd_BUBLB = np.load(prefix + '/BUBLB.npy')  # 是无向图
    nd_BLB = np.load(prefix + '/BLB.npy')  # 是无向图

    nd_BUB[nd_BUB != 0] = 1
    nd_BSB[nd_BSB != 0] = 1
    nd_BUBSB[nd_BUBSB != 0] = 1
    nd_BUBLB[nd_BUBLB != 0] = 1
    nd_BLB[nd_BLB != 0] = 1

    BUB = nd_BUB
    BSB = nd_BSB
    BUBSB = nd_BUBSB
    BUBLB = nd_BUBLB
    BLB = nd_BLB

    adj = BUB + BSB + BUBSB + BUBLB
    # adj = BUB + BSB + BLB + BUBSB + BUBLB
    adj = torch.Tensor(adj)
    adj = (adj - torch.min(adj)) / (torch.max(adj) - torch.min(adj))  # 5、同构图

    labels = torch.LongTensor(labels)  # 3、标签

    num_classes = 3  # 标签类属

    return features[0], labels, num_classes, adj
