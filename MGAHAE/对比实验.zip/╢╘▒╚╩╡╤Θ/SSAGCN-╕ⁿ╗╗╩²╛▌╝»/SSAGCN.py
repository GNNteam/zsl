# coding=utf-8
# Author: Jung
# Time: 2022/8/15 10:14

import warnings
warnings.filterwarnings("ignore")
import torch
import numpy as np
import dgl
from dgl.nn import GraphConv
import torch.nn as nn
import argparse
from sklearn import metrics
import random
import torch.nn.functional as F
from sklearn.metrics.pairwise import cosine_similarity
import networkx as nx
from scipy import sparse
import pickle as pkl
import community
import pickle
import scipy
import scipy.sparse as sp


def modularity(adj: np.array, pred: np.array):
    """
    非重叠模块度
    :param adj: 邻接矩阵
    :param pred: 预测社区标签
    :return:
    """
    # graph = nx.from_numpy_matrix(adj)  # 将一个 NumPy 数组 adj 转换为 NetworkX 图对象 graph
    graph = nx.from_numpy_array(adj)
    part = pred.tolist()  # 将Tensor转换为list格式
    index = range(0, len(part))  # 得到（0,2708）的索引范围
    dic = zip(index, part)
    part = dict(dic)  # 将索引对应的标签生成键值对字典
    modur = community.modularity(part, graph)  # 计算社区的模块度
    return modur

#  # 计算预测结果（pred）与真实标签（labels）之间的归一化互信息
def compute_nmi(pred, labels):
    return metrics.normalized_mutual_info_score(labels, pred)
#  ##### 计算预测结果（pred）与真实标签（labels）之间的准确率
def compute_ac(pred, labels):
    return metrics.accuracy_score(labels, pred)
#  ##### 计算预测结果（pred）与真实标签（labels）之间的F1分数。
def computer_f1(pred, labels):
    return metrics.f1_score(labels, pred, average='macro')
# ####### 计算预测结果（pred_labels）与真实标签（true_labels）之间的调整兰德指数。ARI是一种衡量聚类结果与真实标签一致性的指标，其值在-1到1之间，值越接近1表示聚类结果与真实标签越一致。
def computer_ari(true_labels, pred_labels):
    return metrics.adjusted_rand_score(true_labels, pred_labels)

def calculate_entropy(k, pred_labels, feat):
    """
    :param k: 社区个数
    :param pred_labels: 预测社区
    :param num_nodes: 节点的个数
    :param feat: 节点属性
    :return:
    """
    # 初始化两个矩阵

    num_nodes = feat.shape[0]  # 获取节点数量

    label_assemble = np.zeros(shape=(num_nodes, k))  # 生成2708*7的零矩阵
    label_atts = np.zeros(shape=(k, feat.shape[1]))  # 初始化一个形状为 (7,1433) 的零矩阵，用来存储每个社区中节点属性的累加和。
#  #  构建社区独热编码
    label_assemble[range(num_nodes), pred_labels] = 1
    label_assemble = label_assemble.T

    # 遍历每个社区，得到每个社区下有哪些节点，将这些节点在每个属性点的值相加(计算每个社区的属性总和)
    for i in range(k):
        # 如果社区中的值大于0，则获得索引
        node_indx = np.where(label_assemble[i] > 0)  # 找出属于第 i 个社区的节点的索引
        # 获得索引下的所有属性
        node_feat = feat[node_indx]
        label_atts[i] = node_feat.sum(axis=0)  # 计算每个社区的1433维属性，对这些节点的属性按列求和（11,1433）->（1,1433）
#  ####
    __count_attrs = label_atts.sum(axis=1)  # 将每个社区的1433维属性相加，按行求和，得到每个社区的属性和
    __count_attrs = __count_attrs[:, np.newaxis]  # 将总数转换为列向量
    _tmp = label_atts / (__count_attrs + 1e-10)  # 计算每个社区内属性的比例（7,1433），相当于归一化
    p = (_tmp) * - (np.log2(_tmp + 1e-10))  # 计算每个社区内属性比例的熵贡献（7,1433）

    p = p.sum(axis=1)  # 每个社区的熵贡献进行求和，得到每个社区的熵值（7,1）
    label_assemble = label_assemble.sum(axis=1)  # 计算每个社区中节点的数量
    __entropy = (label_assemble / num_nodes) * p  # 计算加权平均熵，考虑了每个社区的节点比例。（每个社区的节点数量/节点总数）*社区熵值
    return __entropy.sum()  # 所有社区的加权平均熵，作为最终的熵值（7,1）


def parse_args():
    parser = argparse.ArgumentParser()
    # parser.add_argument("--dataset", type=str, default="cora", help="dataset")
    parser.add_argument("--dataset", type=str, default="YELP", help="dataset")  # 原同构为"cora"，现异构为DBLP, ACM, YELP
    parser.add_argument('--lr', type=float, default=0.001, help='learning rate')
    parser.add_argument('--epochs', type=int, default=800, help='the number of epochs')
    parser.add_argument('--topk', type=int, default=100, help='top-k')

    return parser.parse_known_args()

def printConfig(args):
    arg2value = {}
    for arg in vars(args):
        arg2value[arg] = getattr(args, arg)
    print(arg2value)

class GCN(nn.Module):
    def __init__(self, feat_dim, hid_dim, k):
        super(GCN, self).__init__()
        self.feat_dim = feat_dim
        self.hid_dim = hid_dim
        self.conv = GraphConv(feat_dim, hid_dim)
        self.conv2 = GraphConv(hid_dim, k)
        self.act = nn.ReLU()
    def forward(self, graph, feat):
        """ Notice: the final h need to use activation function """
        h = self.conv(graph, feat)
        h = self.act(h)
        h = self.conv2(graph, h)
        return h

def knn_graph(feat, topk, weight = False, loop = True):  # 相似性度量生成属性图，输入属性特征矩阵，与主题数：10
    sim_feat = cosine_similarity(feat)  # 计算相似度矩阵
    sim_matrix = np.zeros(shape=(feat.shape[0], feat.shape[0]))  # 初始化相似度矩阵，大小为n*n

    inds = []
    for i in range(sim_feat.shape[0]):  # 确定每个节点的最近邻节点索引，得到2708*11的矩阵
        ind = np.argpartition(sim_feat[i, :], -(topk + 1))[-(topk + 1):]  # 找到每个节点最相似的 topk 个节点的索引，+1是为了后续去除自节点后，选10个邻居，（寻找数组中第 k 大（或小）的元素）
        inds.append(ind)
    for i, vs in enumerate(inds):  # 构建邻接矩阵
        for v in vs:
            if v == i:  # 去除自身节点
                pass
            else:
                if weight is True:
                    sim_matrix[i][v] = sim_feat[i][v]
                    sim_matrix[v][i] = sim_feat[v][i]
                else:  # 一条边产生两个边，产生无向图
                    sim_matrix[i][v] = 1
                    sim_matrix[v][i] = 1

    # # # 转换为稀疏矩阵并构建图
    sp_matrix = sparse.csr_matrix(sim_matrix)
    dgl_matrix = dgl.from_scipy(sp_matrix)
    if loop is True:  # 添加自环（可选）
        dgl_matrix = dgl.add_self_loop(dgl_matrix)
    return dgl_matrix


def load_data(name: str):  # 加载数据集
    if name == "ACM":
        prefix = r'.\Dataset\MGAG_ACM3025'

        nd_PAP = np.load(prefix + '/pap.npy')
        nd_PSP = np.load(prefix + '/psp.npy')
        nd_PSPAP = np.load(prefix + '/pspap.npy')
        nd_PAPSP = np.load(prefix + '/papsp.npy')

        nd_PAP[nd_PAP != 0] = 1
        nd_PSP[nd_PSP != 0] = 1
        nd_PSPAP[nd_PSPAP != 0] = 1
        nd_PAPSP[nd_PAPSP != 0] = 1

        PAP = nd_PAP
        PSP = nd_PSP
        PSPAP = nd_PSPAP
        PAPSP = nd_PAPSP
        adj = PAP + PSP + PSPAP + PAPSP
        # adj = torch.Tensor(adj)
        # adj = (adj - torch.min(adj)) / (torch.max(adj) - torch.min(adj))  # 5、同构图
        with open(prefix + '/feature.pkl', 'rb') as f:
            features = pickle.load(f)
        feature = features[0].numpy()
    elif name == "DBLP":
        prefix = r'.\Dataset\DBLP'

        nd_APA = scipy.sparse.load_npz(prefix + '/apa.npz').A
        nd_APTPA = scipy.sparse.load_npz(prefix + '/aptpa.npz').A
        nd_APCPA = scipy.sparse.load_npz(prefix + '/apvpa.npz').A

        nd_APA[nd_APA != 0] = 1
        nd_APTPA[nd_APTPA != 0] = 1
        nd_APCPA[nd_APCPA != 0] = 1

        APA = nd_APA
        APTPA = nd_APTPA
        APCPA = nd_APCPA

        adj = 0.8 * APA + 0.35 * APTPA + 0.25 * APCPA
        # adj = APA + APTPA + APCPA
        # adj = torch.Tensor(adj)
        # adj = (adj - torch.min(adj)) / (torch.max(adj) - torch.min(adj))  # 5、同构图
        feature = scipy.sparse.load_npz(prefix + '/features_0.npz').toarray()
    elif name == "YELP":
        prefix = r'.\Dataset\YELP'

        nd_BUB = np.load(prefix + '/BUB.npy')  # 是无向图
        nd_BSB = np.load(prefix + '/BSB.npy')  # 是无向图
        nd_BUBSB = np.load(prefix + '/BUBSB.npy')  # 是无向图
        nd_BUBLB = np.load(prefix + '/BUBLB.npy')  # 是无向图
        nd_BLB = np.load(prefix + '/BLB.npy')  # 是无向图

        nd_BUB[nd_BUB != 0] = 1
        nd_BSB[nd_BSB != 0] = 1
        nd_BUBSB[nd_BUBSB != 0] = 1
        nd_BUBLB[nd_BUBLB != 0] = 1
        nd_BLB[nd_BLB != 0] = 1

        BUB = nd_BUB
        BSB = nd_BSB
        BUBSB = nd_BUBSB
        BUBLB = nd_BUBLB
        BLB = nd_BLB

        adj = BUB + BSB + BLB + BUBSB + BUBLB
        # adj = torch.Tensor(adj)
        # adj = (adj - torch.min(adj)) / (torch.max(adj) - torch.min(adj))  # 5、同构图
        with open(prefix + '/feature.pkl', 'rb') as f:
            features = pickle.load(f)
        feature = features[0].numpy()
    else:
        print("该数据集不在考虑范围")

    # adj_array = adj.numpy()
    adj_csr = sp.csr_matrix(adj)  # 转换为稀疏矩阵
    graph = dgl.from_scipy(adj_csr)  # 使用 DGL 创建图
    # graph = dgl.from_scipy(adj.numpy())

    labels = np.load(prefix + '/label.npy')
    return graph, feature, labels

class Attention(nn.Module):
    def __init__(self, emb_dim, hidden_size=16):  # emb_dim = 7
        super(Attention, self).__init__()
        self.project = nn.Sequential(
            nn.Linear(emb_dim, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, 1, bias=False)
        )
    def forward(self, z):  # 输入2708 * 2 * 7的嵌入
        w = self.project(z)  # 两个2708维数据，经过两层全连接，维度降到1
        beta = torch.softmax(w, dim=1)  # softmax计算概率，得到2708*2*1的注意力系数
        return (beta * z).sum(1)  # 叠加每个邻居节点的嵌入, .sum(1)的含义是将数组第1维是元素求和，为了聚合拓扑图信息与属性图信息

class Ays(nn.Module):
    def __init__(self, graph, kgraph, feat, label):
        super(Ays, self).__init__()
        self.graph = graph  # num_nodes=2708, num_edges=13264 构建边的稀疏矩阵
        self.kgraph = kgraph  # num_nodes=2708, num_edges=43592
        self.adj = graph.adjacency_matrix().to_dense()  # 2708*2708
        self.kadj = kgraph.adjacency_matrix().to_dense()
        self.feat = torch.from_numpy(feat).to(torch.float)  # [2708, 1433]
        self.labels = label  # 每个节点的标签类别 7个
        self.num_nodes, self.feat_dim = self.feat.shape
        self.k = len(np.unique(self.labels))  # 社区的数量：7
        self.atten = Attention(self.k)
        self.t = self.k  # number of topics equal number of communities, 主题的数量等于社区的数量

        """
            hid dim 
            Cora: 200
            Citeseer: 90
            uai2010: 90
            pubmed 128
            blogcatalog 128
            flickr 128
            webkb 32
            
        """
        hid = 200
        self.gcn = GCN(self.feat_dim, hid, self.k)  # 经过GCN得到社区数量维度的嵌入
        self.knn_gcn = GCN(self.feat_dim, hid, self.k)
        self.B = self.get_b_of_modularity(self.adj)  # 模块化, 邻接矩阵减去处理后的归一化度矩阵

        """ activate functions """
        self.relu = nn.ReLU()
        self.log_sig = nn.LogSigmoid()  # 使用对Sigmoid的结果计算log解决了Sigmoid梯度消失问题
        self.soft = nn.Softmax(dim=1)
        self.tanh = nn.Tanh()
        self.sig = nn.Sigmoid()
        self.bce_with_log = nn.BCEWithLogitsLoss()  # 用于二元分类任务中。它将sigmoid函数和二元交叉熵损失函数结合在一起


        """ parameters """  # 定义参数，应用Xavier均匀分布初始化
        self.topo_par = nn.Parameter(torch.FloatTensor(self.k, self.k))
        self.feat_par = nn.Parameter(torch.FloatTensor(self.t, self.feat_dim))
        self.topic = nn.Parameter(torch.FloatTensor(self.k, self.t))
        #  # 参数初始化
        torch.nn.init.xavier_uniform_(self.topo_par)
        torch.nn.init.xavier_uniform_(self.feat_par)
        torch.nn.init.xavier_uniform_(self.topic)

    def get_b_of_modularity(self, A):  # 模块化
        K = 1 / (A.sum().item()) * (A.sum(axis=1).reshape(A.shape[0], 1) @ A.sum(axis=1).reshape(1, A.shape[0]))  # 头节点的度与尾节点的度相乘，再归一化
        return A - K  # 边减去度相乘，评估图中社区结构的质量

    def constraint(self):  # 对解码器中，重构拓扑结构与重构属性的中间矩阵（7,7）隐藏参数矩阵进行约束处理，使它们在一定范围内归一化。
        w = self.topo_par.data.clamp(0, 1)  # 将 self.topo_par参数的数值限制在 [0, 1] 的范围内，超出范围的数值将被截断
        col_sums = w.sum(dim=0)
        w = torch.divide(w.t(), torch.reshape(col_sums, (-1, 1))).t()  # 对W进行归一化
        self.topo_par.data = w  # 将处理后的 w 赋值回 self.topo_par.data

        w = self.topic.data.clamp(0, 1)
        col_sums = w.sum(dim=0)
        w = torch.divide(w.t(), torch.reshape(col_sums, (-1, 1))).t()
        self.topic.data = w

    def forward(self):

        h = self.gcn(self.graph, self.feat)  # 通过GCN，得到2708*7维度的拓扑图的节点嵌入

        h_knn = self.gcn(self.kgraph, self.feat)  # embedding of KNN Graph，通过GCN，得到2708*7维度的属性图的节点嵌入

        h_att = self.atten(torch.stack([h, h_knn], dim=1))  # fusion these two representations, torch.stack([h, h_knn], dim=1)=[2, 2708]，得到聚合了拓扑信息与属性信息的节点嵌入：2708*7

        emb_feat = h_att @ self.topic @ self.feat_par  # reconstruction (attribute)重建(属性)，（解码器：[2708,7]*[7,7]*[7,1433]）

        emb_topo = h_att @ self.topo_par @ h_att.t()  # reconstruction (topology)重建(拓扑)，（解码器：[2708,7]*[7,7]*[7,2708]）

        return self.soft(h_att), self.soft(emb_feat), self.soft(emb_topo)  # 输出嵌入、属性重构矩阵，拓扑图重构矩阵


def cluster_acc(y_true, y_pred):
    y_true = y_true - np.min(y_true)

    l1 = list(set(y_true))
    numClass1 = len(l1)

    l2 = list(set(y_pred))
    numClass2 = len(l2)

    ind = 0
    if numClass1 != numClass2:
        for i in l1:
            if i in l2:
                pass
            else:
                y_pred[ind] = i
                ind += 1

    l2 = list(set(y_pred))
    numClass2 = len(l2)

    if numClass1 != numClass2:
        print("error")
        return

    cost = np.zeros((numClass1, numClass2), dtype=int)
    for i, c1 in enumerate(l1):
        mps = [i1 for i1, e1 in enumerate(y_true) if e1 == c1]
        for j, c2 in enumerate(l2):
            mps_d = [i1 for i1 in mps if y_pred[i1] == c2]
            cost[i][j] = len(mps_d)

    from munkres import Munkres
    # match two clustering results by Munkres algorithm
    m = Munkres()
    cost = cost.__neg__().tolist()
    indexes = m.compute(cost)

    # get the match results
    new_predict = np.zeros(len(y_pred))
    for i, c in enumerate(l1):
        # corresponding label in l2:
        c2 = l2[indexes[i][1]]

        # ai is the index with label==c2 in the pred_label list
        ai = [ind for ind, elm in enumerate(y_pred) if elm == c2]
        new_predict[ai] = c

    # 预测标签处理后，得到的指标都有提升。
    acc = metrics.accuracy_score(y_true, new_predict)
    f1_macro = metrics.f1_score(y_true, new_predict, average="macro")
    precision_macro = metrics.precision_score(y_true, new_predict, average="macro")
    recall_macro = metrics.recall_score(y_true, new_predict, average="macro")
    f1_micro = metrics.f1_score(y_true, new_predict, average="micro")
    precision_micro = metrics.precision_score(y_true, new_predict, average="micro")
    recall_micro = metrics.recall_score(y_true, new_predict, average="micro")
    return acc, f1_macro


if __name__ == "__main__":
    args, _ = parse_args()
    printConfig(args)
    graph, feat, label = load_data(args.dataset)  # 加载数据集，拓扑图有13264条边

    kgraph = knn_graph(feat, args.topk)  # top-k number 返回属性子图邻接矩阵，属性图有43586条边

    model = Ays(graph, kgraph, feat, label)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)

    for epoch in range(args.epochs):
        stmp = epoch

        model.train()
        optimizer.zero_grad()

        emb, emb_feat, emb_topo = model()
        feat_loss = F.mse_loss(model.feat, emb_feat)  # loss value of attribute graph，属性图的损失值（使用均方差损失）

        topo_loss = F.mse_loss(model.adj, emb_topo)  # loss value of topology graph，拓扑图的损失值（使用均方差损失）

        modu_loss = torch.trace(emb.t() @ model.B @ emb)  # modularity，模块化（计算对角线元素和）([7,2708]*[2708,2708]*[2708,7]=[7,7])

        loss = 1 * feat_loss + 10 * topo_loss + - modu_loss * 0.01  # 将三个损失叠加
        print(f"属性损失：{feat_loss}， 结构损失：{topo_loss}， 模块度损失：{modu_loss}，###， 总体损失：{loss}")

        model.eval()
        pred = emb.argmax(dim=1)  # 沿着指定维度（dim=1）找出最大值的索引, 为了从节点嵌入得到节点标签
        nmi = compute_nmi(pred, model.labels)  # 得到归一化互信息
        ari = computer_ari(model.labels, pred)  # 得到兰德指数
        label_array = model.labels.tolist()
        acc, f1_macro = cluster_acc(label_array, pred.numpy())
        # Q = modularity(model.adj.numpy(), pred)  # 输入原图的邻接矩阵和预测标签，得到模块度
        # etp = calculate_entropy(model.k, pred.detach().numpy(), model.feat.numpy())  # 计算熵，输入标签类别数、预测标签、属性矩阵
        #  #### 用来评估社区结构的复杂度或者混乱程度
        print(
            'epoch={},  nmi: {:.4f},  ari= {:.4f},  acc = {:.4f},  f1_macro = {:.4f}'.format(
                epoch,
                nmi,
                ari,
                acc,
                f1_macro
            ))
        loss.backward()
        optimizer.step()
        model.constraint()



