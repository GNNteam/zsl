from __future__ import division
from __future__ import print_function

import time
import argparse
import numpy as np

import torch
import torch.nn.functional as F
import torch.optim as optim

from utils import load_data, accuracy
from models import GCN

from evaluation import *
from early_stopper import *
from hin_loader import HIN
from config import HGSLConfig

# import matplotlib.pyplot as plt
# 定义每个 Epoch 的数据
eps = []  # 替换为实际的 Epoch 数量
n_f1 = []  # 替换为实际的训练精确度数据
v_f1 = []  # 替换为实际的验证精确度数据
n_mif1 = []  # 替换为实际的训练精确度数据
v_mif1 = []  # 替换为实际的验证精确度数据


# Training settings
parser = argparse.ArgumentParser()
parser.add_argument('--no-cuda', action='store_true', default=False,
                    help='Disables CUDA training.')
parser.add_argument('--fastmode', action='store_true', default=False,
                    help='Validate during training pass.')
parser.add_argument('--seed', type=int, default=42, help='Random seed.')
# parser.add_argument('--epochs', type=int, default=200,
#                     help='Number of epochs to train.')
parser.add_argument('--lr', type=float, default=0.01,
                    help='Initial learning rate.')
parser.add_argument('--weight_decay', type=float, default=5e-4,
                    help='Weight decay (L2 loss on parameters).')
parser.add_argument('--hidden', type=int, default=16,
                    help='Number of hidden units.')
parser.add_argument('--dropout', type=float, default=0.5,
                    help='Dropout rate (1 - keep probability).')

args = parser.parse_args()
args.cuda = not args.no_cuda and torch.cuda.is_available()

np.random.seed(args.seed)
torch.manual_seed(args.seed)
if args.cuda:
    torch.cuda.manual_seed(args.seed)
# # MAC: option + command + <-
# # Load data
# adj, features, labels, idx_train, idx_val, idx_test = load_data()

dataset = 'acm'
cf = HGSLConfig(dataset)  #定义模型参数以及数据集分配设置
# # ! Modify config
cf.update(args.__dict__)
# # ! Load Graph
g = HIN(cf.dataset)  #加载feature/edges/labels/meta数据集
print(f'Dataset: {cf.dataset}, {g.t_info}')

features, adj, train_x, train_y, val_x, val_y, test_x, test_y, labels = g.to_torch(cf)

# Model and optimizer,构造GCN，初始化参数。两层GCN
model = GCN(nfeat=features.shape[1],
            nhid=args.hidden,
            nclass=labels.max().item() + 1,
            dropout=args.dropout)
optimizer = optim.Adam(model.parameters(),
                       lr=args.lr, weight_decay=args.weight_decay)

if args.cuda:
    model.cuda()
    features = features.cuda()
    adj = adj.cuda()
    labels = labels.cuda()
    train_x = train_x.cuda()
    val_x = val_x.cuda()
    test_x = test_x.cuda()
    train_y = train_y.cuda()
    val_y = val_y.cuda()
    test_y = test_y.cuda()

stopper = EarlyStopping(patience=cf.early_stop, path=cf.checkpoint_file)   #早停设置。防止过拟合
# Train model
t_total = time.time()
dur = []
t_in = time.time()
for epoch in range(cf.epochs):
    t0 = time.time()
    model.train()
    optimizer.zero_grad() # GraphConvolution forward
    output = model(features, adj)   # 运行模型，输入参数 (features, adj)
    loss_train = F.nll_loss(output[train_x], train_y)
    train_maf1, train_mif1 = eval_logits(output, train_x, train_y)
    # acc_train = accuracy(output[idx_train], labels[idx_train])
    loss_train.backward()
    optimizer.step()

    if not args.fastmode:
        # Evaluate validation set performance separately,
        # deactivates dropout during validation run.
        model.eval()
        output = model(features, adj)

    loss_val = F.nll_loss(output[val_x], labels[val_y])
    val_maf1, val_mif1 = eval_logits(output, val_x, val_y)
    # acc_val = accuracy(output[idx_val], labels[idx_val])
    print('Epoch: {:04d}'.format(epoch+1),
          'loss_train: {:.4f}'.format(loss_train.item()),
          'train_maf1: {:.4f}'.format(train_maf1),
          'train_mif1: {:.4f}'.format(train_mif1),
          'loss_val: {:.4f}'.format(loss_val.item()),
          'val_maf1: {:.4f}'.format(val_maf1),
          'val_mif1: {:.4f}'.format(val_mif1),
          'time: {:.4f}s'.format(time.time() - t_total))

    # 為打印賦值
    eps.append(epoch)
    n_f1.append(train_maf1)
    v_f1.append(val_maf1)
    n_mif1.append(train_mif1)
    v_mif1.append(val_mif1)
    dur.append(time.time() - t0)

    if cf.early_stop > 0:
        if stopper.step(val_maf1, model, epoch):
            print(f'Early stopped, loading model from epoch-{stopper.best_epoch}')
            break

if cf.early_stop > 0:
    model.load_state_dict(torch.load(cf.checkpoint_file))
t_mean = np.mean(dur)
t_out = time.time() - t_in
print(f'average_time:{t_mean}/////////########//////////total_time:{t_out}')
print("Optimization Finished!")
print("Total time elapsed: {:.4f}s".format(time.time() - t_total))

model.eval()
output = model(features, adj)
loss_test = F.nll_loss(output[test_x], labels[test_y])
test_maf1, test_mif1 = eval_logits(output, test_x, test_y)
# acc_test = accuracy(output[idx_test], labels[idx_test])
print("Test set results:",
      "loss= {:.4f}".format(loss_test.item()),
      'test_maf1: {:.4f}'.format(test_maf1),
      'test_mif1: {:.4f}'.format(test_mif1),)

# # 绘制F1曲线
# plt.figure(figsize=(10, 6))
# plt.subplot(1, 2, 1)
# plt.plot(eps, n_f1, color='blue', label='Training MAF1')
# plt.plot(eps, v_f1, color='orange', label='Validation MAF1')
# plt.xlabel('Epoch')
# plt.ylabel('F1')
# plt.subplot(1, 2, 2)
# plt.plot(eps, n_f1, color='green', label='Training MIF1')
# plt.plot(eps, v_f1, color='red', label='Validation MIF1')
# plt.xlabel('Epoch')
# plt.ylabel('MIF1')
# plt.suptitle('HGSL in {}'.format(dataset))
# plt.legend()
# plt.show()

