import pickle
import numpy as np
import torch
import torch.nn.functional as F
import scipy


class HIN(object):

    def __init__(self, dataset):   #加载数据
        data_path = f'data/{dataset}/'
        with open(f'{data_path}node_features.pkl', 'rb') as f:
            self.features = pickle.load(f)   #得到节点特征
        with open(f'{data_path}edges.pkl', 'rb') as f:
            self.edges = pickle.load(f)   #得到多个邻接矩阵子图
        with open(f'{data_path}labels.pkl', 'rb') as f:
            self.labels = pickle.load(f)  #train; val; test
        with open(f'{data_path}meta_data.pkl', 'rb') as f:
            self.__dict__.update(pickle.load(f))
        if scipy.sparse.issparse(self.features):
            self.features = self.features.todense()

    def to_torch(self, cf):
        '''
        Returns the torch tensor of the graph.
        Args:
            cf: The ModelConfig file.
        Returns:
            features, adj: feature and adj. matrix
            mp_emb: only available for models that uses mp_list.
            train_x, train_y, val_x, val_y, test_x, test_y: train/val/test index and labels
        '''
        features = torch.from_numpy(self.features).type(torch.FloatTensor)
        train_x, train_y, val_x, val_y, test_x, test_y = self.get_label()

        adj = np.sum(list(self.edges.values())).todense()
        adj = torch.from_numpy(adj).type(torch.FloatTensor)
        adj = F.normalize(adj, dim=1, p=2)
        labels = torch.cat((train_y, val_y, test_y))
        return features, adj, train_x, train_y, val_x, val_y, test_x, test_y, labels

    def get_label(self):
        '''
        Args:
            dev: device (cpu or gpu)

        Returns:
            train_x, train_y, val_x, val_y, test_x, test_y: train/val/test index and labels
        '''
        train_x = torch.from_numpy(np.array(self.labels[0])[:, 0]).type(torch.LongTensor)
        train_y = torch.from_numpy(np.array(self.labels[0])[:, 1]).type(torch.LongTensor)
        val_x = torch.from_numpy(np.array(self.labels[1])[:, 0]).type(torch.LongTensor)
        val_y = torch.from_numpy(np.array(self.labels[1])[:, 1]).type(torch.LongTensor)
        test_x = torch.from_numpy(np.array(self.labels[2])[:, 0]).type(torch.LongTensor)
        test_y = torch.from_numpy(np.array(self.labels[2])[:, 1]).type(torch.LongTensor)
        return train_x, train_y, val_x, val_y, test_x, test_y
