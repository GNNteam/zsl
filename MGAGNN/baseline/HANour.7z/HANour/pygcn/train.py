from __future__ import division
from __future__ import print_function

import time
import argparse
import numpy as np

import torch
import torch.nn.functional as F
import torch.optim as optim

from pygcn.utils import load_data, accuracy

from evaluation import *
from early_stopper import *
from hin_loader import HIN
from config import HGSLConfig

# import matplotlib.pyplot as plt
# # 定义每个 Epoch 的数据
# eps = []  # 替换为实际的 Epoch 数量
# n_f1 = []  # 替换为实际的训练精确度数据
# v_f1 = []  # 替换为实际的验证精确度数据
# n_mif1 = []  # 替换为实际的训练精确度数据
# v_mif1 = []  # 替换为实际的验证精确度数据


# Training settings
parser = argparse.ArgumentParser()
parser.add_argument('--fastmode', action='store_true', default=False,
                    help='Validate during training pass.')
parser.add_argument('--seed', type=int, default=42, help='Random seed.')
parser.add_argument('--lr', type=float, default=0.01,
                    help='Initial learning rate.')
parser.add_argument('--weight_decay', type=float, default=5e-4,
                    help='Weight decay (L2 loss on parameters).')
parser.add_argument('--hidden_units', type=int, default=16,
                    help='Number of hidden units.')
parser.add_argument('--Dropout', type=float, default=0.5,
                    help='Dropout rate (1 - keep probability).')
# parser.add_argument('-s', '--seed', type=int, default=1,
#                     help='Random seed')
parser.add_argument('--num_heads', type=list, default=[2],)
# parser = argparse.ArgumentParser('HAN')
# parser.add_argument('-ld', '--log-dir', type=str, default='results',
#                     help='Dir for saving training results')
# parser.add_argument('--hetero', action='store_true',
#                     help='Use metapath coalescing with DGL\'s own dataset')

args = parser.parse_args()
# args.cuda = not args.no_cuda and torch.cuda.is_available()
dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# np.random.seed(args.seed)
# torch.manual_seed(args.seed)
# if args.cuda:
#     torch.cuda.manual_seed(args.seed)
# # MAC: option + command + <-
# # Load data
# adj, features, labels, idx_train, idx_val, idx_test = load_data()

dataset = 'yelp'
cf = HGSLConfig(dataset)  #定义模型参数以及数据集分配设置
# # ! Modify config
cf.update(args.__dict__)
# # ! Load Graph
g = HIN(cf.dataset)  #加载feature/edges/labels/meta数据集
print(f'Dataset: {cf.dataset}, {g.t_info}')
cf.dev = dev
features, gs, train_x, train_y, val_x, val_y, test_x, test_y, labels = g.to_torch(cf)

from model import HAN

model = HAN(num_meta_paths=len(gs),
            in_size=features.shape[1],
            hidden_size=args.hidden_units,
            out_size=int(labels.max()) + 1,
            num_heads=args.num_heads,
            dropout=args.Dropout)

optimizer = optim.Adam(model.parameters(),
                       lr=args.lr, weight_decay=args.weight_decay)


model.to(dev)
features = features.to(dev)
gs = [graph.to(dev) for graph in gs]
labels = labels.to(dev)
train_x = train_x.to(dev)
val_x = val_x.to(dev)
test_x = test_x.to(dev)
train_y = train_y.to(dev)
val_y = val_y.to(dev)
test_y = test_y.to(dev)

stopper = EarlyStopping(patience=cf.early_stop, path=cf.checkpoint_file)   #早停设置。防止过拟合
# Train model
t_total = time.time()
dur = []
t_in = time.time()
for epoch in range(cf.epochs):
    t0 = time.time()
    model.train()
    optimizer.zero_grad() # GraphConvolution forward
    output = model(gs, features)   # 运行模型，输入参数 (features, adj)
    loss_train = F.nll_loss(output[train_x], train_y)
    train_maf1, train_mif1 = eval_logits(output, train_x, train_y)
    # acc_train = accuracy(output[idx_train], labels[idx_train])
    loss_train.backward()
    optimizer.step()

    if not args.fastmode:
        # Evaluate validation set performance separately,
        # deactivates dropout during validation run.
        model.eval()
        output = model(gs, features)

    loss_val = F.nll_loss(output[val_x], labels[val_y])
    val_maf1, val_mif1 = eval_logits(output, val_x, val_y)
    # acc_val = accuracy(output[idx_val], labels[idx_val])
    print('Epoch: {:04d}'.format(epoch+1),
          'loss_train: {:.4f}'.format(loss_train.item()),
          'train_maf1: {:.4f}'.format(train_maf1),
          'train_mif1: {:.4f}'.format(train_mif1),
          'loss_val: {:.4f}'.format(loss_val.item()),
          'val_maf1: {:.4f}'.format(val_maf1),
          'val_mif1: {:.4f}'.format(val_mif1),
          'time: {:.4f}s'.format(time.time() - t_total))

    # # 為打印賦值
    # eps.append(epoch)
    # n_f1.append(train_maf1)
    # v_f1.append(val_maf1)
    # n_mif1.append(train_mif1)
    # v_mif1.append(val_mif1)
    dur.append(time.time() - t0)

    if cf.early_stop > 0:
        if stopper.step(val_maf1, model, epoch):
            print(f'Early stopped, loading model from epoch-{stopper.best_epoch}')
            break

if cf.early_stop > 0:
    model.load_state_dict(torch.load(cf.checkpoint_file))
print("Optimization Finished!")
print("Total time elapsed: {:.4f}s".format(time.time() - t_total))

model.eval()
output = model(gs, features)
loss_test = F.nll_loss(output[test_x], labels[test_y])
test_maf1, test_mif1 = eval_logits(output, test_x, test_y)
# acc_test = accuracy(output[idx_test], labels[idx_test])
print("Test set results:",
      "loss= {:.4f}".format(loss_test.item()),
      'test_maf1: {:.4f}'.format(test_maf1),
      'test_mif1: {:.4f}'.format(test_mif1),)
t_mean = np.mean(dur)
t_out = time.time() - t_in
print(f'average_time:{t_mean}/////////########//////////total_time:{t_out}')

# 绘制F1曲线
# plt.figure(figsize=(10, 6))
# plt.subplot(1, 2, 1)
# plt.plot(eps, n_f1, color='blue', label='Training MAF1')
# plt.plot(eps, v_f1, color='orange', label='Validation MAF1')
# plt.xlabel('Epoch')
# plt.ylabel('F1')
# plt.subplot(1, 2, 2)
# plt.plot(eps, n_f1, color='green', label='Training MIF1')
# plt.plot(eps, v_f1, color='red', label='Validation MIF1')
# plt.xlabel('Epoch')
# plt.ylabel('MIF1')
# plt.suptitle('HGSL in {}'.format(dataset))
# plt.legend()
# plt.show()

