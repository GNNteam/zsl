import pickle
import numpy as np
import torch
import torch.nn.functional as F
import scipy
from scipy import sparse
import dgl

class HIN(object):

    def __init__(self, dataset):   #加载数据
        self.dataset = dataset
        data_path = f'../data/{dataset}/'
        with open(f'{data_path}node_features.pkl', 'rb') as f:
            self.features = pickle.load(f)   #得到节点特征
        with open(f'{data_path}edges.pkl', 'rb') as f:
            self.edges = pickle.load(f)   #得到多个邻接矩阵子图
        with open(f'{data_path}labels.pkl', 'rb') as f:
            self.labels = pickle.load(f)  #train; val; test
        with open(f'{data_path}meta_data.pkl', 'rb') as f:
            self.__dict__.update(pickle.load(f))
        if scipy.sparse.issparse(self.features):
            self.features = self.features.todense()

    def to_torch(self, cf):
        '''
        Returns the torch tensor of the graph.
        Args:
            cf: The ModelConfig file.
        Returns:
            features, adj: feature and adj. matrix
            mp_emb: only available for models that uses mp_list.
            train_x, train_y, val_x, val_y, test_x, test_y: train/val/test index and labels
        '''
        features = torch.from_numpy(self.features).type(torch.FloatTensor)
        train_x, train_y, val_x, val_y, test_x, test_y = self.get_label()

        # adj = np.sum(list(self.edges.values())).todense()
        # adj = torch.from_numpy(adj).type(torch.FloatTensor)
        # adj = F.normalize(adj, dim=1, p=2)
        labels = torch.cat((train_y, val_y, test_y))
        gs = []
        if self.dataset == 'dblp':
            num_nodes = 2957
            features = features[: num_nodes, :]
            apa = (self.edges['a-p']*self.edges['p-a']).toarray()
            apcpa = (self.edges['a-p']*self.edges['p-c']*self.edges['c-p']*self.edges['p-a']).toarray()
            data = {'apa': apa[:num_nodes, :num_nodes], 'apcpa': apcpa[:num_nodes, :num_nodes]}
            data['apa'] = sparse.csr_matrix(data['apa'] - np.eye(num_nodes))
            data['apcpa'] = sparse.csr_matrix(data['apcpa'] - np.eye(num_nodes))
            author_g = dgl.from_scipy(data['apa'])  # 定义p-a-p的meta-path; # 建立dgl格式的graph
            subject_g = dgl.from_scipy(data['apcpa'])  # 定义p-s-p的meta-path
            author_g = dgl.add_self_loop(author_g)
            subject_g = dgl.add_self_loop(subject_g)
            gs = [author_g, subject_g]
        elif self.dataset == 'yelp':
            num_nodes = 2614
            features = features[: num_nodes, :]
            bub = (self.edges['b-u'] * self.edges['u-b']).toarray()
            blb = (self.edges['b-l'] * self.edges['l-b']).toarray()
            bsb = (self.edges['b-s'] * self.edges['s-b']).toarray()
            data = {'bub': bub[:num_nodes, :num_nodes], 'blb': blb[:num_nodes, :num_nodes],
                    'bsb': bsb[:num_nodes, :num_nodes]}
            data['bub'] = sparse.csr_matrix(data['bub'] - np.eye(num_nodes))
            data['blb'] = sparse.csr_matrix(data['blb'] - np.eye(num_nodes))
            data['bsb'] = sparse.csr_matrix(data['bsb'] - np.eye(num_nodes))
            author_g = dgl.from_scipy(data['bub'])  # 定义p-a-p的meta-path; # 建立dgl格式的graph
            subject_g = dgl.from_scipy(data['bsb'])  # 定义p-s-p的meta-path
            l_g = dgl.from_scipy(data['blb'])
            author_g = dgl.add_self_loop(author_g)
            subject_g = dgl.add_self_loop(subject_g)
            l_g = dgl.add_self_loop(l_g)
            gs = [author_g, subject_g, l_g]
        else:
            num_nodes = 3025
            features = features[: num_nodes, :]
            pap = (self.edges['p-a'] * self.edges['a-p']).toarray()
            psp = (self.edges['p-s'] * self.edges['s-p']).toarray()
            data = {'pap': pap[:num_nodes, :num_nodes], 'psp': psp[:num_nodes, :num_nodes]}
            data['pap'] = sparse.csr_matrix(data['pap'] - np.eye(num_nodes))
            data['psp'] = sparse.csr_matrix(data['psp'] - np.eye(num_nodes))
            author_g = dgl.from_scipy(data['pap'])  # 定义p-a-p的meta-path; # 建立dgl格式的graph
            subject_g = dgl.from_scipy(data['psp'])  # 定义p-s-p的meta-path
            author_g = dgl.add_self_loop(author_g)
            subject_g = dgl.add_self_loop(subject_g)
            gs = [author_g, subject_g]


        return features, gs, train_x, train_y, val_x, val_y, test_x, test_y, labels

    def get_label(self):
        '''
        Args:
            dev: device (cpu or gpu)

        Returns:
            train_x, train_y, val_x, val_y, test_x, test_y: train/val/test index and labels
        '''
        train_x = torch.from_numpy(np.array(self.labels[0])[:, 0]).type(torch.LongTensor)
        train_y = torch.from_numpy(np.array(self.labels[0])[:, 1]).type(torch.LongTensor)
        val_x = torch.from_numpy(np.array(self.labels[1])[:, 0]).type(torch.LongTensor)
        val_y = torch.from_numpy(np.array(self.labels[1])[:, 1]).type(torch.LongTensor)
        test_x = torch.from_numpy(np.array(self.labels[2])[:, 0]).type(torch.LongTensor)
        test_y = torch.from_numpy(np.array(self.labels[2])[:, 1]).type(torch.LongTensor)
        return train_x, train_y, val_x, val_y, test_x, test_y
